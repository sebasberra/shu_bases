/*
SQLyog Community v12.01 (32 bit)
MySQL - 10.0.25-MariaDB : Database - hmi2_v1_0_00
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `altas_transitorias` */

DROP TABLE IF EXISTS `altas_transitorias`;

CREATE TABLE `altas_transitorias` (
  `id_alta_transitoria` int(11) NOT NULL AUTO_INCREMENT,
  `id_pase` int(10) unsigned NOT NULL,
  `fecha_alta` datetime NOT NULL COMMENT 'fecha del alta transitoria',
  `fecha_probable_regreso` datetime NOT NULL COMMENT 'fecha que se estima que volvera el paciente',
  `acomp_apellido` varchar(255) NOT NULL COMMENT 'apellido del acompañante',
  `acomp_nombre` varchar(255) NOT NULL COMMENT 'nombre del acompañante',
  `acomp_telefono` varchar(255) DEFAULT NULL COMMENT 'telefono del acompañant',
  `medico_idperson` int(11) NOT NULL COMMENT 'medico que autoriza el alta transitoria. idPerson de la table person de diagnose turnos',
  PRIMARY KEY (`id_alta_transitoria`),
  KEY `idx_fk_altas_transitorias_id_pase` (`id_pase`),
  CONSTRAINT `fk_altas_transitorias_id_pase` FOREIGN KEY (`id_pase`) REFERENCES `pases` (`id_pase`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='altas transitorias: fecha probable de regreso, etc';

/*Table structure for table `camas` */

DROP TABLE IF EXISTS `camas`;

CREATE TABLE `camas` (
  `id_cama` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_clasificacion_cama` tinyint(3) unsigned NOT NULL COMMENT 'clasificacion de cama',
  `id_efector` int(10) unsigned NOT NULL COMMENT 'Se guarda el id del efector para cuando la cama no esta asignada a una habitacion',
  `id_habitacion` int(10) unsigned DEFAULT NULL COMMENT 'para camas rotativas esta permitido que la cama no este asignada a una habitacion en un momento dado',
  `id_internacion` int(10) unsigned DEFAULT NULL COMMENT 'Id de internacion de quien esta ocupando la cama. Si es NULL la cama esta vacia',
  `nombre` varchar(50) NOT NULL,
  `estado` char(1) NOT NULL COMMENT 'L=libre; O=ocupada; F=fuera de servicio; R=en reparacion; V=reservada',
  `rotativa` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=no es rotativa, 1=es rotativa; Las camas rotativas pueden cambiarse de habitacion o sala o no estar asignada a una habitacion en un momento dado',
  `baja` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = habilitada; 1 = baja',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cama`),
  UNIQUE KEY `idx_unique_id_internacion` (`id_internacion`),
  UNIQUE KEY `idx_unique_nombre_id_habitacion` (`nombre`,`id_habitacion`),
  KEY `idx_fk_camas_id_habitacion` (`id_habitacion`),
  KEY `idx_fk_camas_id_efector` (`id_efector`),
  KEY `idx_fk_camas_id_clasificacion_cama` (`id_clasificacion_cama`),
  CONSTRAINT `fk_camas_id_clasificacion_cama` FOREIGN KEY (`id_clasificacion_cama`) REFERENCES `clasificaciones_camas` (`id_clasificacion_cama`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_camas_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_camas_id_habitacion` FOREIGN KEY (`id_habitacion`) REFERENCES `habitaciones` (`id_habitacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_camas_id_internacion` FOREIGN KEY (`id_internacion`) REFERENCES `internaciones` (`id_internacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='camas comunes, camillas, incubadoras, etc';

/*Table structure for table `censos_diarios` */

DROP TABLE IF EXISTS `censos_diarios`;

CREATE TABLE `censos_diarios` (
  `id_censo_diario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_efector_servicio` int(10) unsigned DEFAULT NULL COMMENT 'Cuando id_efector_servicio IS NULL entonces es el total de la sala',
  `id_sala` int(10) unsigned DEFAULT NULL COMMENT 'Id de la sala censada. Cuando es NULL entonces es registro global del servicio en el efector',
  `fecha_censo` date NOT NULL COMMENT 'Dia del censo',
  `existencia_0` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de pacientes que estan en la sala a las 0hs',
  `ingresos` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de pacientes que ingresaron, sin contar los pases_de',
  `pases_de` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de ingresos de pacientes que provienen de otras salas (independiente del servicio)',
  `pases_de_servicios` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Cantidad de pacientes que entran al servicio de la sala, pero que provengan de un servicio distinto al del registro (id_efector_servicio)',
  `altas` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de egresos por alta',
  `defunciones_menos_48` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de pacientes que fallecieron ese dia y estuvieron internados en esa sala menos de 48 hs',
  `defunciones_mas_48` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la cantidad de pacientes que fallecieron ese dia y estuvieron internados en esa sala mas de 48 hs',
  `pases_a` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Son los pacientes que pasaron a otra sala',
  `pases_a_servicios` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Cantidad de pacientes que salen del servicio de la sala, con destino a un servicio distinto al del registro (id_efector_servicio)',
  `existencia_24` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'existencia_0 + los ingresos + pases_de - egresos - pases_a',
  `entradas_salidas_dia` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Son solo los pacientes que entraron y egresaron (por alta u obito) ese dia, sin tener en cuenta los pases',
  `pacientes_dia` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la suma de la existencia 24hs mas la cantidad de pacientes que entraron ese dia, sin importar que se hallan ido',
  `dias_estada` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es la sumatoria de los dias que estuvieron internados los pacientes egresados ese dia',
  `total_camas_sala` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Son la cantidad de camas que existen en esa sala, sin tener en cuenta el estado de la cama',
  `camas_disponibles` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Es el total de camas que esten en condiciones de uso y/o en uso de esa sala para ese dia. Editable por programa',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_censo_diario`),
  KEY `idx_id_efector_servicio` (`id_efector_servicio`),
  KEY `idx_id_sala` (`id_sala`),
  KEY `idx_fecha_censo` (`fecha_censo`),
  CONSTRAINT `fk_censos_diarios_id_efector_servicio` FOREIGN KEY (`id_efector_servicio`) REFERENCES `efectores_servicios` (`id_efector_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_censos_diarios_id_sala` FOREIGN KEY (`id_sala`) REFERENCES `salas` (`id_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='registra los censos diarios';

/*Table structure for table `ciex_3` */

DROP TABLE IF EXISTS `ciex_3`;

CREATE TABLE `ciex_3` (
  `id_ciex_3` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cod_3dig` char(3) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `desc_red` varchar(50) NOT NULL,
  PRIMARY KEY (`id_ciex_3`),
  UNIQUE KEY `idx_unique_cod_3dig` (`cod_3dig`),
  KEY `idx_descripcion` (`descripcion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='patologias de 3 digitos de la CIE10';

/*Table structure for table `ciex_4` */

DROP TABLE IF EXISTS `ciex_4`;

CREATE TABLE `ciex_4` (
  `id_ciex_4` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ciex_3` int(10) unsigned NOT NULL,
  `cod_3dig` char(3) NOT NULL,
  `cod_4dig` char(1) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `desc_red` varchar(50) NOT NULL,
  `informa_c2` enum('0','1','2') NOT NULL COMMENT '0 = no informa; 1 = informar inmediatamente; 2 = informar semanalmente',
  PRIMARY KEY (`id_ciex_4`),
  UNIQUE KEY `idx_unique_cod_3dig_cod_4dig` (`cod_3dig`,`cod_4dig`),
  KEY `idx_descripcion` (`descripcion`),
  KEY `idx_fk_ciex_4_id_ciex_3` (`id_ciex_3`),
  CONSTRAINT `fk_ciex_4_id_ciex_3` FOREIGN KEY (`id_ciex_3`) REFERENCES `ciex_3` (`id_ciex_3`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='especificacion de 4to digito de la cie 10';

/*Table structure for table `ciex_frecuentes_servicios` */

DROP TABLE IF EXISTS `ciex_frecuentes_servicios`;

CREATE TABLE `ciex_frecuentes_servicios` (
  `id_ciex_frecuente_servicio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_servicio` int(10) unsigned DEFAULT NULL,
  `id_ciex_4` int(10) unsigned NOT NULL,
  `cod_servicio` char(3) DEFAULT NULL,
  `cod_3dig` char(3) NOT NULL,
  `cod_4dig` char(1) NOT NULL,
  PRIMARY KEY (`id_ciex_frecuente_servicio`),
  UNIQUE KEY `idx_unique_id_servicio_id_ciex_4` (`id_servicio`,`id_ciex_4`),
  UNIQUE KEY `idx_unique_cod_servicio_cod_3dig_cod_4dig` (`cod_servicio`,`cod_3dig`,`cod_4dig`),
  KEY `idx_fk_ciex_frecuentes_servicios_id_ciex_4` (`id_ciex_4`),
  CONSTRAINT `fk_ciex_frecuentes_servicios_id_ciex_4` FOREIGN KEY (`id_ciex_4`) REFERENCES `ciex_4` (`id_ciex_4`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='relacion patologia-frecuencia del servicio de 3 - incompleto';

/*Table structure for table `ciex_restricciones` */

DROP TABLE IF EXISTS `ciex_restricciones`;

CREATE TABLE `ciex_restricciones` (
  `id_ciex_restriccion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ciex_4` int(10) unsigned DEFAULT NULL COMMENT 'id codigo cie10 de 4 digitos. NOTA: si <> NULL entonces id_ciex_3 y id_ciex_titulo deben ser NULL',
  `id_ciex_3` int(10) unsigned DEFAULT NULL COMMENT 'id cie10 de 3 digitos. NOTA: si <> NULL entonces id_ciex_4 y id_ciex_titulo deben ser NULL',
  `id_ciex_titulo` int(10) unsigned DEFAULT NULL COMMENT 'id de titulo o capitulo de la CIE 10. NOTA: si <> NULL entonces id_ciex_3 y id_ciex_4 deben ser NULL',
  `cod_3dig` char(3) DEFAULT NULL COMMENT 'codigo de 3 digitos para restricciones de 3 y 4 digitos. nota: en restricciones de titulos es NULL',
  `cod_4dig` char(1) DEFAULT NULL COMMENT '4 digito para restricciones de 3 y 4 digitos. nota: en restricciones de titulos es NULL',
  `sexo` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion; 1=solo masculino; 2=solo femenino',
  `frecuencia` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion; 1=poco frecuente; 2=no se codifica; 3=codigo de asterisco; 4=codigo de daga; 5=solo CE',
  `tipoedad_min` tinyint(3) unsigned NOT NULL COMMENT '1=anios; 2=meses; 3=dias; 4=horas; 5=minutos; 9=no tiene restriccion minima',
  `edad_min` tinyint(3) unsigned NOT NULL,
  `tipoedad_max` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion maxima; 1=anios; 2=meses; 3=dias; 4=horas; 5=minutos',
  `edad_max` tinyint(3) unsigned NOT NULL,
  `restriccion_edad` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene; 1=puede pasar; 2=no puede pasar',
  `obstetricia` tinyint(3) unsigned NOT NULL COMMENT '0=no corresponde datos; 1=obliga datos parto; 2=puede o no tener datos de parto; 3=aborto; 4=puede o no tener datos de aborto; 5=no corresponde datos(principal); 6=obligatorio datos de parto(principal); 7=puede o no tener datos de parto(principal); 9=S/I',
  `defuncion` tinyint(3) unsigned NOT NULL COMMENT '0:no es defuncion; 1:defuncion; 9:se ignora',
  `causa_externa` tinyint(3) unsigned NOT NULL COMMENT '0=no es causa externa; 1=diagnostico que obliga completar datos de causa; 2=diagnostico como se produjo de causa externa; 3=codigo no permitido si es causa externa',
  `fecha_vigencia_desde` date NOT NULL COMMENT 'fecha a partir de la cual la restriccion toma vigencia. junto con el id correspondientes crean un indice unico',
  `fecha_vigencia_hasta` date DEFAULT NULL COMMENT 'fecha que indica hasta cuando la restriccion es vigente. si es NULL entonces no tiene fecha de caducidad',
  PRIMARY KEY (`id_ciex_restriccion`),
  UNIQUE KEY `idx_fk_ciex_titulos_id_ciex_titulo` (`id_ciex_titulo`),
  UNIQUE KEY `idx_unique_id_ciex_3_fecha_vigencia_desde` (`id_ciex_3`,`fecha_vigencia_desde`),
  UNIQUE KEY `idx_unique_id_ciex_4_fecha_vigencia_desde` (`id_ciex_4`,`fecha_vigencia_desde`),
  UNIQUE KEY `idx_unique_id_ciex_titulo_fecha_vigencia_desde` (`id_ciex_titulo`,`fecha_vigencia_desde`),
  KEY `idx_fk_ciex_3_id_ciex_3` (`id_ciex_3`),
  KEY `idx_fk_ciex_4_id_ciex_4` (`id_ciex_4`),
  KEY `idx_cod_3dig` (`cod_3dig`),
  KEY `idx_cod_4dig` (`cod_4dig`),
  KEY `idx_fecha_vigencia_desde` (`fecha_vigencia_desde`),
  KEY `idx_fecha_vigencia_hasta` (`fecha_vigencia_hasta`),
  CONSTRAINT `fk_ciex_restricciones_id_ciex_3` FOREIGN KEY (`id_ciex_3`) REFERENCES `ciex_3` (`id_ciex_3`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ciex_restricciones_id_ciex_4` FOREIGN KEY (`id_ciex_4`) REFERENCES `ciex_4` (`id_ciex_4`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ciex_restricciones_id_ciex_titulo` FOREIGN KEY (`id_ciex_titulo`) REFERENCES `ciex_titulos` (`id_ciex_titulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Restric. CIE10: edad, sexo, frecuencia, operacion y vigencia';

/*Table structure for table `ciex_restricciones_operaciones` */

DROP TABLE IF EXISTS `ciex_restricciones_operaciones`;

CREATE TABLE `ciex_restricciones_operaciones` (
  `id_ciex_restriccion_operaciones` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NOTA: ciex_restricciones_operaciones es una continuacion de la ciex_restricciones, de manera que mantiene la idea de piramide donde la restriccion de mas detalle (4 digito) esta sobre la de menos detalle',
  `id_ciex_restriccion` int(10) unsigned NOT NULL COMMENT 'id_ciex_restriccion a la cual se le aplica la restriccion de rango de operaciones',
  `id_operacion_desde` int(10) unsigned NOT NULL COMMENT 'id_operacion desde del rango de operaciones que se aplica a la restriccion de la cie 10 ',
  `id_operacion_hasta` int(10) unsigned NOT NULL COMMENT 'id_operacion hasta del rango de operaciones que se aplica a la restriccion de la cie 10',
  `cod_operacion_desde` char(4) NOT NULL COMMENT 'cod_operacion desde del rango de operaciones que se aplica a la restriccion de la cie 10',
  `cod_operacion_hasta` char(4) NOT NULL COMMENT 'cod_operacion hasta del rango de operaciones que se aplica a la restriccion de la cie 10',
  `restriccion_operacion` tinyint(3) unsigned NOT NULL COMMENT '0:sin restriccion; \n    1:obliga operacion;\n    2:no puede tener operacion; \n    3=puede o no tener operacion; \n    4=obliga operacion si datos RN;\n    9=se ignora',
  PRIMARY KEY (`id_ciex_restriccion_operaciones`),
  UNIQUE KEY `idx_unique_id_ciex_restriccion_id_operacion_desde` (`id_ciex_restriccion`,`id_operacion_desde`),
  UNIQUE KEY `idx_unique_id_ciex_restriccion_cod_operacion_desde` (`id_ciex_restriccion`,`cod_operacion_desde`),
  UNIQUE KEY `idx_unique_id_ciex_restriccion_id_operacion_hasta` (`id_ciex_restriccion`,`id_operacion_hasta`),
  UNIQUE KEY `idx_unique_id_ciex_restriccion_cod_operacion_hasta` (`cod_operacion_hasta`,`id_ciex_restriccion`),
  KEY `idx_fk_id_ciex_restriccion` (`id_ciex_restriccion`),
  KEY `idx_fk_id_operacion_desde` (`id_operacion_desde`),
  KEY `idx_fk_id_operacion_hasta` (`id_operacion_hasta`),
  KEY `idx_cod_operacion_desde` (`cod_operacion_desde`),
  KEY `idx_cod_operacion_hasta` (`cod_operacion_hasta`),
  CONSTRAINT `fk_ciex_restricciones_operaciones_id_ciex_restriccion` FOREIGN KEY (`id_ciex_restriccion`) REFERENCES `ciex_restricciones` (`id_ciex_restriccion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ciex_restricciones_operaciones_id_operacion_desde` FOREIGN KEY (`id_operacion_desde`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ciex_restricciones_operaciones_id_operacion_hasta` FOREIGN KEY (`id_operacion_hasta`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='restricc CIE10 de rango de operaciones';

/*Table structure for table `ciex_titulos` */

DROP TABLE IF EXISTS `ciex_titulos`;

CREATE TABLE `ciex_titulos` (
  `id_ciex_titulo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ciex_3_desde` int(10) unsigned NOT NULL,
  `id_ciex_3_hasta` int(10) unsigned NOT NULL,
  `capitulo` char(2) NOT NULL,
  `grupo` char(2) NOT NULL,
  `subgrupo` char(2) NOT NULL,
  `cod_3dig_desde` char(3) NOT NULL,
  `cod_3dig_hasta` char(3) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `desc_red` varchar(50) NOT NULL,
  PRIMARY KEY (`id_ciex_titulo`),
  KEY `idx_cod_3dig_desde` (`cod_3dig_desde`),
  KEY `idx_cod_3dig_hasta` (`cod_3dig_hasta`),
  KEY `idx_fk_ciex_titulos_id_ciex_3_desde` (`id_ciex_3_desde`),
  KEY `idx_fk_ciex_titulos_id_ciex_3_hasta` (`id_ciex_3_hasta`),
  CONSTRAINT `fk_ciex_titulos_id_ciex_3_desde` FOREIGN KEY (`id_ciex_3_desde`) REFERENCES `ciex_3` (`id_ciex_3`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ciex_titulos_id_ciex_3_hasta` FOREIGN KEY (`id_ciex_3_hasta`) REFERENCES `ciex_3` (`id_ciex_3`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='nombre de titulos de grupos y subgrupos de la CIE10';

/*Table structure for table `clasificaciones_camas` */

DROP TABLE IF EXISTS `clasificaciones_camas`;

CREATE TABLE `clasificaciones_camas` (
  `id_clasificacion_cama` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `clasificacion_cama` varchar(50) NOT NULL COMMENT 'Descripcion de la clasificacion',
  `abreviatura` char(5) NOT NULL COMMENT 'Abreviatura de la descripcion',
  `definicion` text COMMENT 'Informacion extra',
  `tipo_cuidado_progresivo` tinyint(4) NOT NULL COMMENT '0= cuidado moderado; 1= cuidado intermedio ; 2=cuidado critico',
  `critica` tinyint(1) NOT NULL COMMENT '0= NO critica; 1= critica',
  `categoria_edad` char(5) NOT NULL COMMENT 'ADU= adulto (>14 a); PED= pediatrica (>28 d y <14 a); NEO= neonatologica (<28 d)',
  `oxigeno` tinyint(1) NOT NULL COMMENT '0 = sin oxigeno ; 1 = con oxigeno',
  `respirador` tinyint(1) NOT NULL COMMENT '0= sin respirador; 1= con respirador',
  `aislamiento` tinyint(4) NOT NULL COMMENT '0= sin aislamiento; 1= con aislamiento (casos donde el paciente debe estar aislado de los otros por el tipo de efermedad)',
  `fecha_expiracion` date DEFAULT NULL COMMENT 'Fecha de baja de la clasificacion, NULL si la clasificacion esta activa',
  PRIMARY KEY (`id_clasificacion_cama`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tipos de cama propuestos por Stettler y compatibles con sisa';

/*Table structure for table `codigos_hmi` */

DROP TABLE IF EXISTS `codigos_hmi`;

CREATE TABLE `codigos_hmi` (
  `id_codigo_hmi` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_hmi` char(2) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `tipo_codigo` tinyint(3) unsigned NOT NULL,
  `desc_tipo_codigo` varchar(50) NOT NULL,
  `restriccion` char(1) DEFAULT NULL COMMENT 'Campo para agregar una restriccion al registro',
  PRIMARY KEY (`id_codigo_hmi`),
  UNIQUE KEY `idx_unique_codigo_hmi_tipo_codigo` (`codigo_hmi`,`tipo_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='repositorio de los codigos estadisticos del HMI';

/*Table structure for table `configuraciones_sistemas` */

DROP TABLE IF EXISTS `configuraciones_sistemas`;

CREATE TABLE `configuraciones_sistemas` (
  `id_configuracion_sistema` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_efector` int(10) unsigned NOT NULL,
  `activa` tinyint(1) NOT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_configuracion_sistema`),
  KEY `idx_fk_configuraciones_sistemas_id_efector` (`id_efector`),
  CONSTRAINT `fk_configuraciones_sistemas_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='activa el efector donde se esta corriendo el hmi2';

/*Table structure for table `departamentos` */

DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id_dpto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_prov` int(10) unsigned NOT NULL,
  `nom_dpto` varchar(50) NOT NULL,
  `cod_dpto` char(3) NOT NULL,
  PRIMARY KEY (`id_dpto`),
  KEY `idx_fk_departamentos_id_prov` (`id_prov`),
  KEY `idx_nom_dpto` (`nom_dpto`),
  CONSTRAINT `fk_departamentos_id_prov` FOREIGN KEY (`id_prov`) REFERENCES `provincias` (`id_prov`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='departamentos de las provincias arg (solo santa fe) ';

/*Table structure for table `dependencias_administrativas` */

DROP TABLE IF EXISTS `dependencias_administrativas`;

CREATE TABLE `dependencias_administrativas` (
  `id_dependencia_adm` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `cod_dep_adm` char(1) NOT NULL,
  `nom_dep_adm` varchar(50) NOT NULL,
  `tipo_dep_adm` char(1) NOT NULL,
  PRIMARY KEY (`id_dependencia_adm`),
  UNIQUE KEY `idx_unique_cod_dep_adm` (`cod_dep_adm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Determina la dependencia administrativa del efector';

/*Table structure for table `diagnosticos` */

DROP TABLE IF EXISTS `diagnosticos`;

CREATE TABLE `diagnosticos` (
  `id_diagnostico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_ciex_4` int(10) unsigned NOT NULL,
  `id_internacion` int(10) unsigned NOT NULL,
  `cod_3dig` char(3) NOT NULL,
  `cod_4dig` char(1) NOT NULL,
  `nro_orden` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_diagnostico`),
  UNIQUE KEY `idx_unique_fk_diagnosticos_id_internacion_id_ciex_4` (`id_internacion`,`id_ciex_4`),
  UNIQUE KEY `idx_unique_id_internacion_cod_3dig_cod_4dig` (`id_internacion`,`cod_3dig`,`cod_4dig`),
  KEY `idx_fk_diagnosticos_id_ciex_4` (`id_ciex_4`),
  KEY `idx_cod_3dig` (`cod_3dig`),
  CONSTRAINT `fk_diagnosticos_id_ciex_4` FOREIGN KEY (`id_ciex_4`) REFERENCES `ciex_4` (`id_ciex_4`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_diagnosticos_id_internacion` FOREIGN KEY (`id_internacion`) REFERENCES `internaciones` (`id_internacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='diagnosticos de la internacion';

/*Table structure for table `efectores` */

DROP TABLE IF EXISTS `efectores`;

CREATE TABLE `efectores` (
  `id_efector` int(10) unsigned NOT NULL,
  `id_nodo` smallint(5) unsigned NOT NULL,
  `id_subnodo` smallint(5) unsigned NOT NULL,
  `id_localidad` int(10) unsigned NOT NULL,
  `id_dependencia_adm` tinyint(3) unsigned DEFAULT NULL,
  `id_regimen_juridico` tinyint(3) unsigned NOT NULL,
  `id_nivel_complejidad` tinyint(3) unsigned NOT NULL COMMENT 'Nivel de complejidad del ejector. Ver tabla niveles_complejidades',
  `claveestd` varchar(8) NOT NULL,
  `clavesisa` char(14) DEFAULT NULL COMMENT 'clave SISA (Sistema Integrado de Informacion Argentino)',
  `tipo_efector` char(1) DEFAULT NULL COMMENT 'tipo establecimiento para el informe de estadistica',
  `nom_efector` varchar(255) NOT NULL,
  `nom_red_efector` varchar(50) NOT NULL,
  `nodo` tinyint(4) unsigned NOT NULL,
  `subnodo` smallint(6) unsigned NOT NULL,
  `internacion` tinyint(1) NOT NULL COMMENT 'Indica si el efector tiene internacion o no',
  `baja` tinyint(1) NOT NULL COMMENT 'Indica si el efector esta activo o fue dado de baja',
  PRIMARY KEY (`id_efector`),
  UNIQUE KEY `idx_unique_claveestd` (`claveestd`),
  KEY `idx_fk_efectores_id_localidad` (`id_localidad`),
  KEY `idx_fk_efectores_id_dependencia_adm` (`id_dependencia_adm`),
  KEY `idx_fk_efectores_id_regimen_juridico` (`id_regimen_juridico`),
  KEY `idx_fk_efectores_id_nodo` (`id_nodo`),
  KEY `idx_fk_efectores_id_subnodo` (`id_subnodo`),
  KEY `idx_fk_efectores_id_nivel_complejidad` (`id_nivel_complejidad`),
  KEY `idx_clavesisa` (`clavesisa`),
  KEY `idx_nom_efector` (`nom_efector`),
  CONSTRAINT `fk_efectores_id_dependencia_adm` FOREIGN KEY (`id_dependencia_adm`) REFERENCES `dependencias_administrativas` (`id_dependencia_adm`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_id_localidad` FOREIGN KEY (`id_localidad`) REFERENCES `localidades` (`id_localidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_id_nivel_complejidad` FOREIGN KEY (`id_nivel_complejidad`) REFERENCES `niveles_complejidades` (`id_nivel_complejidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_id_nodo` FOREIGN KEY (`id_nodo`) REFERENCES `nodos` (`id_nodo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_id_regimen_juridica` FOREIGN KEY (`id_regimen_juridico`) REFERENCES `regimenes_juridicos` (`id_regimen_juridico`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_id_subnodo` FOREIGN KEY (`id_subnodo`) REFERENCES `subnodos` (`id_subnodo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='efectores publicos y privados de la provincia de santa fe';

/*Table structure for table `efectores_servicios` */

DROP TABLE IF EXISTS `efectores_servicios`;

CREATE TABLE `efectores_servicios` (
  `id_efector_servicio` int(10) unsigned NOT NULL COMMENT 'concatenacion del id_efector con el id_servicio_estadistica. los nuevos valores pueden obtenerse con la funcion get_id_efector_servicio',
  `id_efector` int(10) unsigned NOT NULL COMMENT 'id del efector donde se ha habilitado el servicio de 5 digitos',
  `id_servicio_estadistica` int(10) unsigned NOT NULL COMMENT 'id del servicio de 5 digitos de estadistica',
  `claveestd` char(8) NOT NULL COMMENT 'codigo de establecimiento de 8 digitos obtenido del mod_sims',
  `cod_servicio` char(3) NOT NULL COMMENT 'codigo nuclear de servicios de nacion vigente desde 2008',
  `sector` char(1) NOT NULL COMMENT '1=varones; 2=mujeres; 3=mixto; 8=especificacion',
  `subsector` char(1) NOT NULL COMMENT '4=internacion; 5=CE; 6=atencion domiciliaria',
  `nom_servicio_estadistica` varchar(255) NOT NULL COMMENT 'Nombre del servicio de estadistica. Este campo se agrego para facilitar los select y reportes en programacion',
  `baja` tinyint(4) NOT NULL COMMENT 'estado actual del servicio en el efector: 0=alta; 1=baja',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'fecha de actualizacion del registro',
  PRIMARY KEY (`id_efector_servicio`),
  UNIQUE KEY `idx_unique_claveestd_cod_servicio_sector_subsector` (`claveestd`,`cod_servicio`,`sector`,`subsector`),
  UNIQUE KEY `idx_unique_id_efector_id_servicio_estadistica` (`id_efector`,`id_servicio_estadistica`),
  KEY `idx_fk_efectores_servicios_id_efector` (`id_efector`),
  KEY `idx_fk_efectores_servicios_id_servicio_estadistica` (`id_servicio_estadistica`),
  CONSTRAINT `fk_efectores_servicios_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_efectores_servicios_id_servicio_estadistica` FOREIGN KEY (`id_servicio_estadistica`) REFERENCES `servicios_estadistica` (`id_servicio_estadistica`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='servicios habilitados por estadistica en el efector';

/*Table structure for table `efectores_servicios_hist` */

DROP TABLE IF EXISTS `efectores_servicios_hist`;

CREATE TABLE `efectores_servicios_hist` (
  `id_efector_servicio_hist` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_efector_servicio` int(10) unsigned NOT NULL,
  `fecha_apertura` date NOT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'fecha de modificacion del registro',
  PRIMARY KEY (`id_efector_servicio_hist`),
  UNIQUE KEY `idx_unique_id_efector_servicio_fecha_apertura` (`id_efector_servicio`,`fecha_apertura`),
  KEY `idx_fk_id_efector_servicio` (`id_efector_servicio`),
  CONSTRAINT `fk_efectores_servicios_hist_id_efector_servicio` FOREIGN KEY (`id_efector_servicio`) REFERENCES `efectores_servicios` (`id_efector_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='historico de apertura y cierre de servicios de los efectores';

/*Table structure for table `habitaciones` */

DROP TABLE IF EXISTS `habitaciones`;

CREATE TABLE `habitaciones` (
  `id_habitacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_sala` int(10) unsigned NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `sexo` tinyint(3) unsigned NOT NULL COMMENT '1=hombre; 2=mujer; 3=indeterminado',
  `edad_desde` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `edad_hasta` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `tipo_edad` char(1) NOT NULL COMMENT '1=años; 2=meses; 3=días; 4=horas; 5=minutos; 6=ignora',
  `cant_camas` smallint(5) unsigned NOT NULL COMMENT 'cantidad de camas de la habitacion',
  `baja` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = habilitada; 1 = baja',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_habitacion`),
  UNIQUE KEY `idx_unique_nombre_id_sala` (`nombre`,`id_sala`),
  KEY `idx_fk_habitaciones_id_sala` (`id_sala`),
  CONSTRAINT `fk_habitaciones_id_sala` FOREIGN KEY (`id_sala`) REFERENCES `salas` (`id_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='habitaciones fisicas que se asocian a una sala';

/*Table structure for table `internaciones` */

DROP TABLE IF EXISTS `internaciones`;

CREATE TABLE `internaciones` (
  `id_internacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_efector` int(10) unsigned NOT NULL COMMENT 'Efector de donde es la internacion',
  `ing_id_servicio_estadistica` int(10) unsigned NOT NULL COMMENT 'Id del servicio que interna al paciente',
  `egr_id_servicio_estadistica` int(10) unsigned DEFAULT NULL COMMENT 'Id del servicio que egresa al paciente',
  `id_localidad` int(10) unsigned NOT NULL COMMENT 'id_localidad del paciente',
  `deriv1_id_efector` int(10) unsigned DEFAULT NULL COMMENT 'Establecimiento derivador',
  `diag_presuntivo_id_ciex_4` int(10) unsigned DEFAULT NULL COMMENT 'ciex_4.id_ciex_4 de diagnostico presuntivo',
  `causa_ext_id_ciex_4` int(10) unsigned DEFAULT NULL COMMENT 'ciex_4.id_ciex_4 de causa externa',
  `deriv2_id_efector` int(10) unsigned DEFAULT NULL COMMENT 'Establecimiento al que se deriva',
  `periodo_informe` char(4) NOT NULL COMMENT 'Año de informe, junto con el nro de informe son unicos',
  `nro_informe` int(10) unsigned NOT NULL COMMENT 'Numero de informe de hospitalizacion. Junto con el periodo de informe son unicos',
  `claveestd` char(8) NOT NULL COMMENT 'Codigo de establecimiento que genera el informe',
  `nom_efector` varchar(255) NOT NULL COMMENT 'Nombre del establecimiento que genera el informe',
  `cod_dpto` char(3) NOT NULL COMMENT 'Codigo de dpto. del estab. que genera el informe',
  `nodo` tinyint(3) unsigned NOT NULL COMMENT 'Nodo del estab. que genera el informe',
  `cod_dep_adm` char(1) NOT NULL COMMENT 'Codigo dependencia administrativa del estab. que genera el informe',
  `id_paciente` int(10) unsigned NOT NULL COMMENT 'Paciente internado. id_paciente de la tabla diagnose.paciente',
  `id_persona` int(10) unsigned DEFAULT NULL COMMENT 'id_persona de la tabla "personas" de la base personas 2.0 o posterior',
  `apellido` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `sexo` char(1) NOT NULL COMMENT 'Sexo del paciente',
  `dom_calle` varchar(255) NOT NULL COMMENT 'Residencia habitual del paciente',
  `dom_nro` varchar(20) NOT NULL,
  `dom_piso` varchar(10) DEFAULT NULL,
  `dom_dpto` varchar(10) DEFAULT NULL,
  `dom_telefono` varchar(80) DEFAULT NULL,
  `dom_barrio` varchar(255) DEFAULT NULL,
  `dom_cod_loc` char(2) NOT NULL,
  `dom_cod_dpto` char(3) NOT NULL,
  `dom_cod_prov` char(2) NOT NULL,
  `dom_cod_pais` char(3) NOT NULL,
  `os_asociado_a` char(1) NOT NULL COMMENT '1=obra social; 2=plan de salud priv. o laboral; 3=plan o seguro publico; 4=mas de uno; 5=ninguno; 6=se ignora',
  `os_nombre` varchar(255) DEFAULT NULL COMMENT 'Nombre de la obra social del paciente',
  `os_rnos` char(6) DEFAULT NULL COMMENT 'Codigo de RNOS de la obra social del paciente',
  `os_condicion` char(1) DEFAULT NULL COMMENT 'Condicion del paciente en la obra social',
  `situacion_laboral` char(1) NOT NULL COMMENT '1=trabaja o esta de licencia; 2=busca trabajo; 3=no busca trabajo',
  `instruccion` char(2) NOT NULL COMMENT 'Ver tabla "codigos_hmi"',
  `ocupacion_habitual` char(5) NOT NULL DEFAULT '99999' COMMENT 'No existe hasta el momento una tabla de ocupacion habitual, de completa con 99999',
  `ing_hospitalizado_por` char(1) NOT NULL COMMENT '1=consultorio externo; 2=emergencia; 4=sala de parto; 5=otros',
  `ing_fecha_hora` datetime NOT NULL,
  `ing_edad` tinyint(3) unsigned NOT NULL,
  `ing_tipo_edad` char(1) NOT NULL COMMENT '1=años; 2=meses; 3=dias; 4=horas; 5=minutos; 6=se ignora',
  `ing_medio_traslado` char(1) DEFAULT NULL COMMENT '1=DIPAES; 2=ambulancia privada; 3=ambulancia comunal; 4=otros; 5=sin especificar',
  `ing_cod_servicio` char(3) NOT NULL COMMENT 'Servicio de ingreso, codigo de 3 digitos',
  `ing_sector` char(1) NOT NULL COMMENT 'Sector de ingreso: 1=varones; 2=mujeres; 3=mixto',
  `ing_subsector` char(1) NOT NULL COMMENT 'Subsector de ingreso: 4=internacion; 5=CE; 6=atencion domiciliaria',
  `ing_medico_idperson` int(10) unsigned DEFAULT NULL COMMENT 'Medico que autoriza la internacion. IdPerson de la tabla diagnose.person',
  `ing_derivado` tinyint(1) NOT NULL COMMENT 'Indica si el paciente ingresa derivado de otro establecimiento o no',
  `ing_hc_sies` int(10) unsigned DEFAULT NULL COMMENT 'historia clinica o de intervencion del sies 107',
  `ing_judicial` tinyint(4) NOT NULL COMMENT 'indica si es un ingreso judicial',
  `ing_judicial_observacion` varchar(255) DEFAULT NULL COMMENT 'observacion para caso judicial',
  `deriv1_claveestd` char(8) DEFAULT NULL COMMENT 'deriv1 = info del establecimiento derivador',
  `deriv1_nom_efector` varchar(255) DEFAULT NULL COMMENT 'Nombre efector derivado "de". Puede ser o no un efector provincial',
  `deriv1_cod_dep_adm` char(1) DEFAULT NULL,
  `deriv1_cod_loc` char(2) DEFAULT NULL,
  `deriv1_cod_dpto` char(3) DEFAULT NULL,
  `deriv1_cod_prov` char(2) DEFAULT NULL,
  `deriv1_cod_pais` char(3) DEFAULT NULL,
  `diag_presuntivo_texto` varchar(255) NOT NULL,
  `diag_principal_texto` varchar(255) DEFAULT NULL,
  `egr_fecha_hora` datetime DEFAULT NULL,
  `egr_total_dias_estada` smallint(5) unsigned DEFAULT NULL,
  `egr_prorroga` tinyint(1) DEFAULT NULL COMMENT 'Indica si por otras circunstancias se prolonga la internacion (caso social)',
  `egr_dias_prorroga` smallint(5) unsigned DEFAULT NULL,
  `egr_tipo` char(1) DEFAULT NULL COMMENT '1=alta medica; 2=traslado otro establecimiento; 3=alta transitoria; 4=retiro voluntario; 5=defuncion; 6=otros',
  `egr_medio_traslado` char(1) DEFAULT NULL COMMENT '1=DIPAES; 2=ambulancia privada; 3=ambulancia comunal; 4=otros; 5=sin especificar',
  `egr_autopsia` tinyint(1) DEFAULT NULL COMMENT 'El tipo de egreso (egr_tipo) debe ser = 5 (defuncion)',
  `egr_cod_servicio` char(3) DEFAULT NULL COMMENT 'Servicio de ingreso, codigo de 3 digitos',
  `egr_sector` char(1) DEFAULT NULL COMMENT 'Sector de ingreso: 1=varones; 2=mujeres; 3=mixto',
  `egr_subsector` char(1) DEFAULT NULL COMMENT 'Subsector de ingreso: 4=internacion; 5=CE; 6=atencion domiciliaria',
  `egr_completo` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Bandera que indica si esta completa la info de egreso',
  `egr_medico_idperson` int(10) unsigned DEFAULT NULL COMMENT 'Medico interviniente (firma el informe de egreso). IdPerson de la tabla diagnose.person',
  `causa_ext_producido_por` char(1) DEFAULT NULL COMMENT '1=Accidente; 2=Lesiones autoinfligidas; 3=Agresiones; 4=Se ignora',
  `causa_ext_lugar` char(1) DEFAULT NULL COMMENT 'Lugar donde ocurrio la causa externa',
  `causa_ext_descripcion` varchar(255) DEFAULT NULL COMMENT 'Descripcion de la circunstancia o situacion en la que acontecio el hecho',
  `deriv2_claveestd` char(8) DEFAULT NULL COMMENT 'deriv2 = info del establecimiento al que se deriva',
  `deriv2_nom_efector` varchar(255) DEFAULT NULL COMMENT 'Nombre efector derivado "a". Puede ser o no un efector provincial',
  `deriv2_cod_dep_adm` char(1) DEFAULT NULL,
  `deriv2_cod_loc` char(2) DEFAULT NULL,
  `deriv2_cod_dpto` char(3) DEFAULT NULL,
  `deriv2_cod_prov` char(2) DEFAULT NULL,
  `deriv2_cod_pais` char(3) DEFAULT NULL,
  `nac_fecha` date DEFAULT NULL COMMENT 'Fecha de terminacion del embarazo',
  `nac_semanas_gest` tinyint(3) unsigned DEFAULT NULL COMMENT 'Semanas de gestacion',
  `nac_paridad` tinyint(3) unsigned DEFAULT NULL COMMENT 'Total nacimientos anteriores al presente',
  `nac_parto_multiple` tinyint(1) DEFAULT NULL COMMENT '0=no es parto; 1=simple; 2=doble; 3=triple; 4=cuat.; 5=quint; 6=mas de 5',
  `esp_pred_cod_servicio` char(3) DEFAULT NULL COMMENT 'Especialidad predominante (servicios.cod_servicio)',
  `backup_id_tipo_doc` tinyint(3) unsigned NOT NULL COMMENT 'Tipo de documento al momento de ingresar la internacion - Segun HMI original (ver tabla codigos_hmi) 1=DNI;2=LC;3=LE;4=CI;5=OTR',
  `backup_nro_doc` int(10) unsigned NOT NULL COMMENT 'Numero de documento al momento de ingresar la interncion',
  `backup_egr_medico_id_tipo_doc` tinyint(3) unsigned DEFAULT NULL COMMENT 'Tipo de documento del medico interviniente - Segun HMI original (ver tabla codigos_hmi) 1=DNI;2=LC;3=LE;4=CI;5=OTR',
  `backup_egr_medico_nro_doc` int(10) unsigned DEFAULT NULL COMMENT 'Numero de documento del medico interviniente',
  `backup_egr_medico_matricula` smallint(5) unsigned DEFAULT NULL COMMENT 'Matricula del medico interviniente',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_internacion`),
  UNIQUE KEY `idx_unique_periodo_informe_nro_informe_id_efector` (`periodo_informe`,`nro_informe`,`id_efector`),
  UNIQUE KEY `idx_unique_periodo_informe_nro_informe_claveestd` (`periodo_informe`,`nro_informe`,`claveestd`),
  UNIQUE KEY `idx_unique_ing_hc_sies` (`ing_hc_sies`),
  KEY `idx_fk_internaciones_id_efector` (`id_efector`),
  KEY `idx_fk_internaciones_id_efector_derivado_de` (`deriv1_id_efector`),
  KEY `idx_fk_internaciones_id_efector_derivado_a` (`deriv2_id_efector`),
  KEY `idx_fk_internaciones_id_localidad` (`id_localidad`),
  KEY `idx_fk_internaciones_diag_presuntivo_id_ciex_4` (`diag_presuntivo_id_ciex_4`),
  KEY `idx_fk_internaciones_causa_ext_id_ciex_4` (`causa_ext_id_ciex_4`),
  KEY `idx_apellido` (`apellido`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_ing_fecha_hora` (`ing_fecha_hora`),
  KEY `idx_egr_fecha_hora` (`egr_fecha_hora`),
  KEY `idx_ing_id_servicio_estadistica` (`ing_id_servicio_estadistica`),
  KEY `idx_egr_id_servicio_estadistica` (`egr_id_servicio_estadistica`),
  KEY `idx_esp_pred_cod_servicio` (`esp_pred_cod_servicio`),
  KEY `idx_backup_nro_doc` (`backup_nro_doc`,`backup_id_tipo_doc`),
  KEY `idx_id_persona` (`id_persona`),
  KEY `idx_os_rnos` (`os_rnos`),
  KEY `idx_nro_informe` (`nro_informe`),
  KEY `idx_diag_presuntivo_texto` (`diag_presuntivo_texto`(10)),
  KEY `idx_diag_principal_texto` (`diag_principal_texto`(10)),
  KEY `idx_causa_ext_descripcion` (`causa_ext_descripcion`(10)),
  KEY `idx_id_paciente` (`id_paciente`),
  CONSTRAINT `fk_internaciones_causa_ext_id_ciex_4` FOREIGN KEY (`causa_ext_id_ciex_4`) REFERENCES `ciex_4` (`id_ciex_4`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_diag_presuntivo_id_ciex_4` FOREIGN KEY (`diag_presuntivo_id_ciex_4`) REFERENCES `ciex_4` (`id_ciex_4`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_egr_id_servicio_estadistica` FOREIGN KEY (`egr_id_servicio_estadistica`) REFERENCES `servicios_estadistica` (`id_servicio_estadistica`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_id_efector_derivado_a` FOREIGN KEY (`deriv2_id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_id_efector_derivado_de` FOREIGN KEY (`deriv1_id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_id_localidad` FOREIGN KEY (`id_localidad`) REFERENCES `localidades` (`id_localidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_ing_id_servicio_estadistica` FOREIGN KEY (`ing_id_servicio_estadistica`) REFERENCES `servicios_estadistica` (`id_servicio_estadistica`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='registro de internaciones';

/*Table structure for table `internaciones_operaciones` */

DROP TABLE IF EXISTS `internaciones_operaciones`;

CREATE TABLE `internaciones_operaciones` (
  `id_internacion_operacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_internacion` int(10) unsigned NOT NULL,
  `id_operacion` int(10) unsigned NOT NULL,
  `nro_orden` tinyint(3) unsigned NOT NULL COMMENT '0 = operacion principal',
  `fecha_operacion` date NOT NULL,
  `dias_preparatoria` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_internacion_operacion`),
  UNIQUE KEY `idx_unique_id_internacion_nro_orden` (`id_internacion`,`nro_orden`),
  UNIQUE KEY `idx_unique_id_internacion_id_operacion_fecha_operacion` (`id_internacion`,`id_operacion`,`fecha_operacion`),
  KEY `idx_fk_internaciones_operaciones_id_operacion` (`id_operacion`),
  KEY `idx_fk_internaciones_operaciones_id_internacion` (`id_internacion`),
  CONSTRAINT `fk_internaciones_operaciones_id_internacion` FOREIGN KEY (`id_internacion`) REFERENCES `internaciones` (`id_internacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_internaciones_operaciones_id_operacion` FOREIGN KEY (`id_operacion`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='operaciones de la internacion';

/*Table structure for table `localidades` */

DROP TABLE IF EXISTS `localidades`;

CREATE TABLE `localidades` (
  `id_localidad` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_dpto` int(10) unsigned DEFAULT NULL,
  `nom_loc` varchar(50) NOT NULL,
  `cod_loc` char(2) NOT NULL,
  `cod_dpto` char(3) NOT NULL,
  `cod_prov` char(2) NOT NULL,
  `cod_pais` char(3) NOT NULL,
  `cod_postal` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id_localidad`),
  UNIQUE KEY `idx_unique_cod_loc_cod_dpto_cod_prov_cod_pais` (`cod_loc`,`cod_dpto`,`cod_prov`,`cod_pais`),
  KEY `idx_fk_localidades_id_dpto` (`id_dpto`),
  KEY `idx_nom_loc` (`nom_loc`),
  CONSTRAINT `fk_localidades_id_dpto` FOREIGN KEY (`id_dpto`) REFERENCES `departamentos` (`id_dpto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='localidades, departamentos, provincias y paises con codigos ';

/*Table structure for table `nacimientos` */

DROP TABLE IF EXISTS `nacimientos`;

CREATE TABLE `nacimientos` (
  `id_nacimiento` int(11) NOT NULL AUTO_INCREMENT,
  `id_internacion` int(10) unsigned NOT NULL,
  `peso` smallint(5) unsigned NOT NULL COMMENT 'Peso al nacer en gramos',
  `condicion_al_nacer` tinyint(3) unsigned NOT NULL COMMENT '1=nacido vivo; 2=defuncion fetal',
  `terminacion` tinyint(3) unsigned NOT NULL COMMENT '1=vaginal; 2=cesarea',
  `sexo` tinyint(3) unsigned NOT NULL COMMENT '1=masculino; 2=femenino; 3=indeterminado',
  PRIMARY KEY (`id_nacimiento`),
  KEY `fk_nacimientos_id_internacion_idx` (`id_internacion`),
  CONSTRAINT `fk_nacimientos_id_internacion` FOREIGN KEY (`id_internacion`) REFERENCES `internaciones` (`id_internacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='informacion del recien nacido';

/*Table structure for table `niveles_complejidades` */

DROP TABLE IF EXISTS `niveles_complejidades`;

CREATE TABLE `niveles_complejidades` (
  `id_nivel_complejidad` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nivcomest` varchar(4) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  PRIMARY KEY (`id_nivel_complejidad`),
  UNIQUE KEY `idx_unique_nivcomest` (`nivcomest`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='niveles de complejidad de los efectores';

/*Table structure for table `nodos` */

DROP TABLE IF EXISTS `nodos`;

CREATE TABLE `nodos` (
  `id_nodo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nom_nodo` varchar(255) NOT NULL,
  `numregion` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_nodo`),
  UNIQUE KEY `idx_unique_numregion` (`numregion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='nodos de la division zonal de la provincia de santa fe';

/*Table structure for table `operaciones` */

DROP TABLE IF EXISTS `operaciones`;

CREATE TABLE `operaciones` (
  `id_operacion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cod_operacion` char(4) NOT NULL,
  `nom_operacion` varchar(255) NOT NULL,
  `nom_red_operacion` varchar(30) NOT NULL,
  PRIMARY KEY (`id_operacion`),
  UNIQUE KEY `idx_unique_cod_operacion` (`cod_operacion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='operaciones segun codificacion 2009';

/*Table structure for table `operaciones_ciex_titulos_restricciones` */

DROP TABLE IF EXISTS `operaciones_ciex_titulos_restricciones`;

CREATE TABLE `operaciones_ciex_titulos_restricciones` (
  `id_operacion_ciex_titulo_restriccion` int(11) NOT NULL AUTO_INCREMENT,
  `id_operacion_titulo` int(10) unsigned NOT NULL,
  `id_ciex_titulo` int(10) unsigned NOT NULL,
  `restriccion` tinyint(3) NOT NULL COMMENT '0:no tiene restriccion; 1:advertir; 2:no puede pasar',
  PRIMARY KEY (`id_operacion_ciex_titulo_restriccion`),
  UNIQUE KEY `idx_unique_id_operacion_titulo_id_ciex_titulo` (`id_ciex_titulo`,`id_operacion_titulo`),
  KEY `idx_fk_operaciones_ciex_titulos_id_operacion_titulo` (`id_operacion_titulo`),
  KEY `idx_fk_operaciones_ciex_titulos_id_ciex_titulo` (`id_ciex_titulo`),
  CONSTRAINT `fk_operaciones_ciex_titulos_id_ciex_titulo` FOREIGN KEY (`id_ciex_titulo`) REFERENCES `ciex_titulos` (`id_ciex_titulo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_operaciones_ciex_titulos_id_operacion_titulo` FOREIGN KEY (`id_operacion_titulo`) REFERENCES `operaciones_titulos` (`id_operacion_titulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `operaciones_restricciones` */

DROP TABLE IF EXISTS `operaciones_restricciones`;

CREATE TABLE `operaciones_restricciones` (
  `id_operacion_restriccion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_operacion` int(10) unsigned NOT NULL,
  `cod_operacion` char(4) NOT NULL,
  `sexo` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion; 1=solo masculino; 2=solo femenino',
  `frecuencia` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion; 1=poco frecuente; 2=no puede aparecer',
  `tipoedad_min` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene restriccion; 1=años; 2=meses; 3=dias; 4=horas; 5=minutos',
  `edad_min` tinyint(3) unsigned NOT NULL,
  `tipoedad_max` tinyint(3) unsigned NOT NULL COMMENT '1=años; 2=meses; 3=dias; 4=horas; 5=minutos; 9=no tiene restriccion maxima',
  `edad_max` tinyint(3) unsigned NOT NULL,
  `restriccion_edad` tinyint(3) unsigned NOT NULL COMMENT '0=no tiene; 1=puede pasar; 2=no puede pasar',
  PRIMARY KEY (`id_operacion_restriccion`),
  UNIQUE KEY `idx_unique_cod_operacion` (`cod_operacion`),
  KEY `idx_fk_operaciones_restricciones_id_operacion` (`id_operacion`),
  CONSTRAINT `fk_operaciones_restricciones_id_operacion` FOREIGN KEY (`id_operacion`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='restricciones de operaciones (solo estructura, sin datos)';

/*Table structure for table `operaciones_titulos` */

DROP TABLE IF EXISTS `operaciones_titulos`;

CREATE TABLE `operaciones_titulos` (
  `id_operacion_titulo` int(10) unsigned NOT NULL,
  `id_operacion_desde` int(10) unsigned NOT NULL COMMENT 'id_operacion de inicio de titulo',
  `id_operacion_hasta` int(10) unsigned NOT NULL COMMENT 'id_operacion de finalizacion de titulo',
  `capitulo` smallint(6) NOT NULL COMMENT 'lista tabular de procedimientos',
  `cod_operacion_desde` char(4) NOT NULL COMMENT 'cod_operacion de inicio del titulo',
  `cod_operacion_hasta` char(4) NOT NULL COMMENT 'cod_operacion de finalizacion del titulo',
  `descripcion` varchar(255) NOT NULL COMMENT 'descripcion del titulo',
  `desc_red` varchar(50) NOT NULL COMMENT 'descripcion reducida del titulo',
  PRIMARY KEY (`id_operacion_titulo`),
  UNIQUE KEY `idx_unique_descripcion` (`descripcion`),
  UNIQUE KEY `idx_unique_desc_red` (`desc_red`),
  KEY `idx_fk_id_operacion_desde` (`id_operacion_desde`),
  KEY `idx_fk_id_operacion_hasta` (`id_operacion_hasta`),
  CONSTRAINT `fk_operaciones_titulos_id_operacion_desde` FOREIGN KEY (`id_operacion_desde`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_operaciones_titulos_id_operacion_hasta` FOREIGN KEY (`id_operacion_hasta`) REFERENCES `operaciones` (`id_operacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Capitulos y titulos de operaciones';

/*Table structure for table `paises` */

DROP TABLE IF EXISTS `paises`;

CREATE TABLE `paises` (
  `id_pais` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom_pais` varchar(50) NOT NULL,
  `cod_pais` char(3) NOT NULL,
  PRIMARY KEY (`id_pais`),
  KEY `idx_nom_pais` (`nom_pais`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='paises con codigos estandar';

/*Table structure for table `pases` */

DROP TABLE IF EXISTS `pases`;

CREATE TABLE `pases` (
  `id_pase` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_censo_diario` int(10) unsigned DEFAULT NULL,
  `id_internacion` int(10) unsigned NOT NULL,
  `id_servicio_sala_entrada` int(10) unsigned NOT NULL,
  `fecha_entrada` datetime NOT NULL,
  `tipo_entrada` char(1) NOT NULL COMMENT 'I=ingreso; P=pase de; R=Reingreso;',
  `id_servicio_sala_salida` int(10) unsigned DEFAULT NULL,
  `fecha_salida` datetime DEFAULT NULL,
  `tipo_salida` char(1) DEFAULT NULL COMMENT 'A=alta medica; O=obito; P=pase a; T=alta transitoria;',
  `dias_estada` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'fecha_entrada - fecha_salida + 1 o 0 si fecha_salida es NULL',
  `id_pase_siguiente` int(10) unsigned DEFAULT NULL COMMENT 'id_pase del siguiente pase, si existe',
  `id_habitacion` int(10) unsigned NOT NULL COMMENT 'id_habitacion de la cama en ese momento (permite movimiento de camas)',
  `id_cama` int(10) unsigned NOT NULL COMMENT 'No debe restringir el ingreso si la cama esta ocupada',
  `estado_pase` char(1) NOT NULL COMMENT 'P=pendiente; A=aceptado; E=egresado; I=inconcluso (altas donde el paciente no se retiro del hospital);',
  `observacion_pase` text,
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pase`),
  KEY `idx_fk_pases_id_internacion` (`id_internacion`),
  KEY `idx_fk_pases_id_servicio_sala_entrada` (`id_servicio_sala_entrada`),
  KEY `idx_fk_pases_id_servicio_sala_salida` (`id_servicio_sala_salida`),
  KEY `idx_fk_pases_id_habitacion` (`id_habitacion`),
  KEY `idx_fk_pases_id_cama` (`id_cama`),
  KEY `idx_fk_pases_id_censo_diario` (`id_censo_diario`),
  KEY `idx_fk_pases_id_pase_siguiente` (`id_pase_siguiente`),
  KEY `idx_idx_fecha_entrada` (`fecha_entrada`),
  KEY `idx_fecha_salida` (`fecha_salida`),
  CONSTRAINT `fk_pases_id_cama` FOREIGN KEY (`id_cama`) REFERENCES `camas` (`id_cama`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_censo_diario` FOREIGN KEY (`id_censo_diario`) REFERENCES `censos_diarios` (`id_censo_diario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_habitacion` FOREIGN KEY (`id_habitacion`) REFERENCES `habitaciones` (`id_habitacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_internacion` FOREIGN KEY (`id_internacion`) REFERENCES `internaciones` (`id_internacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_pase_siguiente` FOREIGN KEY (`id_pase_siguiente`) REFERENCES `pases` (`id_pase`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_servicio_sala_entrada` FOREIGN KEY (`id_servicio_sala_entrada`) REFERENCES `servicios_salas` (`id_servicio_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pases_id_servicio_sala_salida` FOREIGN KEY (`id_servicio_sala_salida`) REFERENCES `servicios_salas` (`id_servicio_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='movimientos: ingresos, pases, egresos y estados intermedios';

/*Table structure for table `provincias` */

DROP TABLE IF EXISTS `provincias`;

CREATE TABLE `provincias` (
  `id_prov` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pais` int(10) unsigned NOT NULL,
  `nom_prov` varchar(50) NOT NULL,
  `cod_prov` char(2) NOT NULL,
  PRIMARY KEY (`id_prov`),
  KEY `idx_fk_provincias_id_pais` (`id_pais`),
  KEY `idx_nom_prov` (`nom_prov`),
  CONSTRAINT `fk_provincias_id_pais` FOREIGN KEY (`id_pais`) REFERENCES `paises` (`id_pais`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='provincias con codigos estandar';

/*Table structure for table `regimenes_juridicos` */

DROP TABLE IF EXISTS `regimenes_juridicos`;

CREATE TABLE `regimenes_juridicos` (
  `id_regimen_juridico` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `regjurest` varchar(15) NOT NULL,
  `codigo` char(2) NOT NULL,
  PRIMARY KEY (`id_regimen_juridico`),
  UNIQUE KEY `idx_unique_codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='regimenes juridicos de los efectores';

/*Table structure for table `salas` */

DROP TABLE IF EXISTS `salas`;

CREATE TABLE `salas` (
  `id_sala` int(10) unsigned NOT NULL COMMENT 'concatenacion del id_efector y nro_sala',
  `id_efector` int(10) unsigned NOT NULL COMMENT 'id del efector de donde pertenece la sala',
  `nro_sala` smallint(5) unsigned NOT NULL COMMENT 'nro de sala dentro del efector, se implementa como incremental por efector',
  `nombre` varchar(255) NOT NULL COMMENT 'nombre de la sala dentro del efector',
  `cant_camas` smallint(5) unsigned NOT NULL COMMENT 'cantidad total de camas de la sala',
  `mover_camas` tinyint(1) NOT NULL COMMENT 'bandera para el sistema que indica si se permite mover camas entre las habitaciones de la misma sala. por ejemplo: las incubadoras ',
  `area_id_efector_servicio` int(10) unsigned DEFAULT NULL COMMENT 'id del servicio del efector que es el referente de la sala (concepto de area del SIPES)',
  `area_cod_servicio` char(3) DEFAULT NULL COMMENT 'codigo de 3 digitos del area SIPES',
  `area_sector` char(1) DEFAULT NULL COMMENT 'campo sector correspondiente al area SIPES (1=varones; 2=mujeres; 3=mixto)',
  `area_subsector` char(1) DEFAULT NULL COMMENT 'subsector correspondiente al area SIPES (4=internacion; 5=CE; 6=atencion domiciliaria;7=?internacion;8=?internacion)',
  `baja` tinyint(4) NOT NULL COMMENT 'marca si la sala esta actualmente cerrada',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'fecha de modificacion del registro',
  PRIMARY KEY (`id_sala`),
  UNIQUE KEY `idx_unique_id_efector_nombre` (`id_efector`,`nombre`),
  UNIQUE KEY `idx_unique_id_efector_nro_sala` (`id_efector`,`nro_sala`),
  UNIQUE KEY `idx_unique_id_efector_area_id_efector_servicio` (`area_id_efector_servicio`),
  UNIQUE KEY `idx_unique_id_efector_cod_servicio_sector_subsector` (`id_efector`,`area_cod_servicio`,`area_sector`,`area_subsector`),
  KEY `idx_fk_salas_area_id_efector_servicio` (`area_id_efector_servicio`),
  CONSTRAINT `fk_salas_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_salas_ref_id_efector_servicio` FOREIGN KEY (`area_id_efector_servicio`) REFERENCES `efectores_servicios` (`id_efector_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='sala logica o area en la config. edilicia del efector';

/*Table structure for table `salas_hist` */

DROP TABLE IF EXISTS `salas_hist`;

CREATE TABLE `salas_hist` (
  `id_sala_hist` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id autoincremental',
  `id_sala` int(10) unsigned NOT NULL COMMENT 'una misma sala puede cerrarse o abrirse mas de una vez',
  `fecha_apertura` date NOT NULL COMMENT 'fecha aperura de la sala',
  `fecha_cierre` date DEFAULT NULL COMMENT 'fecha que dejo de funcionar la sala correspondiente a la fecha de apertura',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sala_hist`),
  UNIQUE KEY `idx_unique_id_sala_fecha_apertura` (`id_sala`,`fecha_apertura`),
  KEY `fk_salas_hist_id_sala` (`id_sala`),
  CONSTRAINT `fk_salas_hist_id_sala1` FOREIGN KEY (`id_sala`) REFERENCES `salas` (`id_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='apertura y cierre de salas';

/*Table structure for table `servicios` */

DROP TABLE IF EXISTS `servicios`;

CREATE TABLE `servicios` (
  `id_servicio` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id autoincremental',
  `cod_servicio` char(3) NOT NULL COMMENT 'codigo nuclear de servicios de nacion vigente desde 2008',
  `nom_servicio` varchar(255) NOT NULL COMMENT 'nombre o descripcion del servicio',
  `nom_red_servicio` varchar(30) NOT NULL,
  `diagn_especiales` char(1) DEFAULT NULL COMMENT 'I=diagnostico por imagenes',
  `medico` tinyint(4) NOT NULL COMMENT '0=no tiene definicion como medico o no medico; 1=medico; 2=no medico. NOTA: para servicios de internacion son todos 1',
  `tipo_servicio` tinyint(4) NOT NULL COMMENT '0=no definido; 1=final; 2=intermedio; 3=general',
  PRIMARY KEY (`id_servicio`),
  UNIQUE KEY `idx_unique_cod_servicio` (`cod_servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='servicios que establecio nacion a partir del año 2008';

/*Table structure for table `servicios_estadistica` */

DROP TABLE IF EXISTS `servicios_estadistica`;

CREATE TABLE `servicios_estadistica` (
  `id_servicio_estadistica` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id autoincremental',
  `id_servicio` int(10) unsigned NOT NULL COMMENT 'id de tabla servicios',
  `cod_servicio` char(3) NOT NULL COMMENT 'codigo nuclear de servicios de nacion vigente desde 2008',
  `sector` char(1) NOT NULL COMMENT '1=varones; 2=mujeres; 3=mixto',
  `subsector` char(1) NOT NULL COMMENT '4=internacion; 5=CE; 6=atencion domiciliaria;7=?internacion;8=?internacion',
  `nom_servicio_estadistica` varchar(255) NOT NULL COMMENT 'descripcion del servicio obtenida del SIPES, tabla de servicios de 5 digitos',
  `nom_red_servicio_estadistica` varchar(30) NOT NULL COMMENT 'idem anterios truncada con los primeros 30 caracteres',
  PRIMARY KEY (`id_servicio_estadistica`),
  UNIQUE KEY `idx_unique_cod_servicio_sector_subsector` (`cod_servicio`,`sector`,`subsector`),
  KEY `idx_fk_servicios_estadistica_id_servicio` (`id_servicio`),
  CONSTRAINT `fk_servicios_estadistica_id_servicio` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='servicios que maneja estadistica de la provincia de santa fe';

/*Table structure for table `servicios_salas` */

DROP TABLE IF EXISTS `servicios_salas`;

CREATE TABLE `servicios_salas` (
  `id_servicio_sala` int(10) unsigned NOT NULL COMMENT 'se genera como la concatenacion del id_sala + el id_servicio_estadistica',
  `id_efector` int(10) unsigned NOT NULL COMMENT 'id_efector de donde es el servicio y la sala',
  `id_efector_servicio` int(10) unsigned NOT NULL COMMENT 'id_efector_servicio del servicio del efector',
  `id_sala` int(10) unsigned NOT NULL COMMENT 'id_sala de la sala del efector',
  `agudo_cronico` tinyint(4) NOT NULL COMMENT '1=agudo; 2=cronico',
  `tipo_servicio_sala` tinyint(4) NOT NULL COMMENT '0=comun; 1=hospital de dia; 2=atencion domiciliaria',
  `baja` tinyint(1) NOT NULL COMMENT 'Se puede dar de baja a un servicio de una sala y mantener los pases de este',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'fecha de modificacion del registro',
  PRIMARY KEY (`id_servicio_sala`),
  UNIQUE KEY `idx_unique_id_efector_servicio_id_sala` (`id_efector_servicio`,`id_sala`),
  UNIQUE KEY `idx_unique_id_efector_id_efector_servicio_id_sala` (`id_efector`,`id_efector_servicio`,`id_sala`),
  KEY `idx_fk_servicios_salas_id_sala` (`id_sala`),
  KEY `fk_servicios_salas_id_efector_idx` (`id_efector`),
  CONSTRAINT `fk_servicios_salas_id_efector` FOREIGN KEY (`id_efector`) REFERENCES `efectores` (`id_efector`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_servicios_salas_id_efector_servicio` FOREIGN KEY (`id_efector_servicio`) REFERENCES `efectores_servicios` (`id_efector_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_servicios_salas_id_sala` FOREIGN KEY (`id_sala`) REFERENCES `salas` (`id_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='servicios de 5 digitos habilitados en la sala';

/*Table structure for table `servicios_salas_hist` */

DROP TABLE IF EXISTS `servicios_salas_hist`;

CREATE TABLE `servicios_salas_hist` (
  `id_servicio_sala_hist` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id autoincremental',
  `id_servicio_sala` int(10) unsigned NOT NULL COMMENT 'un mismo servicio puede cerrarse o abrirse mas de una vez dentro de la misma sala',
  `fecha_apertura` date NOT NULL COMMENT 'fecha de apertura del servicio en la sala',
  `fecha_cierre` date DEFAULT NULL COMMENT 'fecha de cierre del servicio en la sala',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'fecha de modificacion del registro',
  PRIMARY KEY (`id_servicio_sala_hist`),
  UNIQUE KEY `idx_unique_id_servicio_sala_fecha_apertura` (`id_servicio_sala`,`fecha_apertura`),
  KEY `idx_fk_servicios_salas_hist_id_servicio_sala` (`id_servicio_sala`),
  CONSTRAINT `fk_servicios_salas_hist_id_servicio_sala` FOREIGN KEY (`id_servicio_sala`) REFERENCES `servicios_salas` (`id_servicio_sala`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='historico de apertura y cierre de servicios en cada sala';

/*Table structure for table `subnodos` */

DROP TABLE IF EXISTS `subnodos`;

CREATE TABLE `subnodos` (
  `id_subnodo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_nodo` smallint(5) unsigned NOT NULL,
  `nom_subnodo` varchar(255) NOT NULL,
  `numregion` tinyint(3) unsigned NOT NULL,
  `numsubregion` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_subnodo`),
  UNIQUE KEY `idx_unique_numregion_numsubregion` (`numregion`,`numsubregion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='subnodos de la division zonal de la provincia de santa fe';

/*Table structure for table `subservicios` */

DROP TABLE IF EXISTS `subservicios`;

CREATE TABLE `subservicios` (
  `id_subservicio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_efector_servicio` int(10) unsigned NOT NULL,
  `id_servicio` int(10) unsigned NOT NULL,
  `claveestd` char(8) NOT NULL,
  `cod_servicio` char(3) NOT NULL,
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_subservicio`),
  UNIQUE KEY `idx_unique_id_efector_servicio_id_servicio` (`id_efector_servicio`,`id_servicio`),
  KEY `idx_fk_subservicios_id_servicio` (`id_servicio`),
  KEY `idx_claveestd_cod_servicio` (`claveestd`,`cod_servicio`),
  CONSTRAINT `fk_subservicios_id_efector_servicio` FOREIGN KEY (`id_efector_servicio`) REFERENCES `efectores_servicios` (`id_efector_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_subservicios_id_servicio` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='solo esta de ejemplo para una posible solucion (sin datos)';

/*Table structure for table `versiones` */

DROP TABLE IF EXISTS `versiones`;

CREATE TABLE `versiones` (
  `base` varchar(255) NOT NULL COMMENT 'nombre de la base de datos a la que corresponde el nro de version',
  `major` tinyint(4) NOT NULL COMMENT 'numero de version major',
  `minor` tinyint(4) NOT NULL COMMENT 'numero de version minor',
  `revision` smallint(6) NOT NULL COMMENT 'numero de revision de la version',
  `fecha` datetime NOT NULL COMMENT 'fecha de generacion de la version',
  PRIMARY KEY (`base`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='versionado de las bases de datos o subconjuntos de tablas';

/* Function  structure for function  `ciex_check_restricciones_edad` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_check_restricciones_edad` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_check_restricciones_edad`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							edad TINYINT, 
    							tipo_edad TINYINT,
    							fecha_vigencia DATE) RETURNS tinyint(4)
    COMMENT '0=OK; 1=NO min; 2=min poco frec; 3=NO max; 4=max poco frec'
BEGIN
	DECLARE tipoedad_min_aux TINYINT;
	DECLARE	edad_min_aux TINYINT;
	DECLARE	tipoedad_max_aux TINYINT;
	DECLARE	edad_max_aux TINYINT;
	DECLARE	restriccion_edad_aux TINYINT;
	
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	WHERE
		cr.cod_3dig = cod_3dig
	AND cr.cod_4dig = cod_4dig
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
        IF tipoedad_min_aux != tipo_edad THEN
        
        	
			
            
            IF tipoedad_min_aux > tipo_edad THEN
            
                
                
                
                SET tipoedad_min_aux = tipoedad_min_aux;
                
            ELSE
            
                
                
                
                
                RETURN 1;
                
            END IF;
        
                
        ELSE
            
       
            
            IF edad_min_aux > edad THEN
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 2;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 1;
                    
                END IF;
                
            END IF;
            
            
		END IF;
		
	END IF;
	
	
	
	
	
	
	
	
	IF tipoedad_max_aux IS NOT NULL THEN
	
	
		
        IF tipoedad_max_aux != tipo_edad THEN
            
            
            
            If tipoedad_max_aux < tipo_edad Then
            
                
                
                
                SET tipoedad_max_aux = tipoedad_max_aux;
                
            ELSE
            
            	
                RETURN 3;
            
            END IF;
            
        ELSE
        
        	
            If edad_max_aux < edad Then
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 4;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 3;
                    
                END IF;
                
            END IF;
            
        END IF;
        
        
	END IF;
	
	
	
	
	
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	WHERE
		cr.cod_3dig = cod_3dig
	AND cr.id_ciex_4 IS NULL
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
        IF tipoedad_min_aux != tipo_edad THEN
        
        	
			
            
            IF tipoedad_min_aux > tipo_edad THEN
            
                
                
                
                SET tipoedad_min_aux = tipoedad_min_aux;
                
            ELSE
            
                
                
                
                
                RETURN 1;
                
            END IF;
        
                
        ELSE
            
       
            
            IF edad_min_aux > edad THEN
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 2;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 1;
                    
                END IF;
                
            END IF;
            
            
		END IF;
		
	END IF;
	
	
	
	
	
	
	
	
	IF tipoedad_max_aux IS NOT NULL THEN
	
	
		
        IF tipoedad_max_aux != tipo_edad THEN
            
            
            
            If tipoedad_max_aux < tipo_edad Then
            
                
                
                
                SET tipoedad_max_aux = tipoedad_max_aux;
                
            ELSE
            
            	
                RETURN 3;
            
            END IF;
            
        ELSE
        
        	
            If edad_max_aux < edad Then
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 4;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 3;
                    
                END IF;
                
            END IF;
            
        END IF;
        
        
	END IF;
	
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	INNER JOIN
		ciex_titulos ct
	ON
		cr.id_ciex_titulo = ct.id_ciex_titulo
	WHERE
		ct.cod_3dig_desde <= cod_3dig
	AND ct.cod_3dig_hasta >= cod_3dig
	AND ct.subgrupo<>'00'
	AND ct.grupo<>'00'
	AND ct.capitulo<>'00'
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
        IF tipoedad_min_aux != tipo_edad THEN
        
        	
			
            
            IF tipoedad_min_aux > tipo_edad THEN
            
                
                
                
                SET tipoedad_min_aux = tipoedad_min_aux;
                
            ELSE
            
                
                
                
                
                RETURN 1;
                
            END IF;
        
                
        ELSE
            
       
            
            IF edad_min_aux > edad THEN
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 2;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 1;
                    
                END IF;
                
            END IF;
            
            
		END IF;
		
	END IF;
	
	
	
	
	
	
	
	
	IF tipoedad_max_aux IS NOT NULL THEN
	
	
		
        IF tipoedad_max_aux != tipo_edad THEN
            
            
            
            If tipoedad_max_aux < tipo_edad Then
            
                
                
                
                SET tipoedad_max_aux = tipoedad_max_aux;
                
            ELSE
            
            	
                RETURN 3;
            
            END IF;
            
        ELSE
        
        	
            If edad_max_aux < edad Then
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 4;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 3;
                    
                END IF;
                
            END IF;
            
        END IF;
        
        
	END IF;
	
	
	
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	INNER JOIN
		ciex_titulos ct
	ON
		cr.id_ciex_titulo = ct.id_ciex_titulo
	WHERE
		ct.cod_3dig_desde <= cod_3dig
	AND ct.cod_3dig_hasta >= cod_3dig
	AND ct.subgrupo='00'
	AND ct.grupo<>'00'
	AND ct.capitulo<>'00'
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
        IF tipoedad_min_aux != tipo_edad THEN
        
        	
			
            
            IF tipoedad_min_aux > tipo_edad THEN
            
                
                
                
                SET tipoedad_min_aux = tipoedad_min_aux;
                
            ELSE
            
                
                
                
                
                RETURN 1;
                
            END IF;
        
                
        ELSE
            
       
            
            IF edad_min_aux > edad THEN
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 2;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 1;
                    
                END IF;
                
            END IF;
            
            
		END IF;
		
	END IF;
	
	
	
	
	
	
	
	
	IF tipoedad_max_aux IS NOT NULL THEN
	
	
		
        IF tipoedad_max_aux != tipo_edad THEN
            
            
            
            If tipoedad_max_aux < tipo_edad Then
            
                
                
                
                SET tipoedad_max_aux = tipoedad_max_aux;
                
            ELSE
            
            	
                RETURN 3;
            
            END IF;
            
        ELSE
        
        	
            If edad_max_aux < edad Then
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 4;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 3;
                    
                END IF;
                
            END IF;
            
        END IF;
        
        
	END IF;
	
	
	
	
	
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	INNER JOIN
		ciex_titulos ct
	ON
		cr.id_ciex_titulo = ct.id_ciex_titulo
	WHERE
		ct.cod_3dig_desde <= cod_3dig
	AND ct.cod_3dig_hasta >= cod_3dig
	AND ct.subgrupo='00'
	AND ct.grupo='00'
	AND ct.capitulo<>'00'
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
        IF tipoedad_min_aux != tipo_edad THEN
        
        	
			
            
            IF tipoedad_min_aux > tipo_edad THEN
            
                
                
                
                SET tipoedad_min_aux = tipoedad_min_aux;
                
            ELSE
            
                
                
                
                
                RETURN 1;
                
            END IF;
        
                
        ELSE
            
       
            
            IF edad_min_aux > edad THEN
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 2;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 1;
                    
                END IF;
                
            END IF;
            
            
		END IF;
		
	END IF;
	
	
	
	
	
	
	
	
	IF tipoedad_max_aux IS NOT NULL THEN
	
	
		
        IF tipoedad_max_aux != tipo_edad THEN
            
            
            
            If tipoedad_max_aux < tipo_edad Then
            
                
                
                
                SET tipoedad_max_aux = tipoedad_max_aux;
                
            ELSE
            
            	
                RETURN 3;
            
            END IF;
            
        ELSE
        
        	
            If edad_max_aux < edad Then
            
                
                IF restriccion_edad_aux = 1 THEN
                
                    RETURN 4;
                    
                END IF;
                
                
                IF restriccion_edad_aux = 2 THEN
                
                    RETURN 3;
                    
                END IF;
                
            END IF;
            
        END IF;
        
        
	END IF;
	
	
	RETURN 0;
	
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_check_restriccion_operacion_no_puede_tener` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_check_restriccion_operacion_no_puede_tener` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_check_restriccion_operacion_no_puede_tener`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(4)
    COMMENT '0:no tiene restriccion;2=no puede tener;9=S/I'
BEGIN
	DECLARE flag_restriccion_operacion_obligatoria TINYINT;
	DECLARE flag_restriccion_operacion_puede_o_no_tener TINYINT;
	
	DECLARE	restriccion_operacion_aux TINYINT;
	DECLARE exit_loop INT; 
	
	
	DECLARE 
		restricciones_operaciones_4
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
	DECLARE 
		restricciones_operaciones_3 
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
		
	DECLARE 
		restricciones_operaciones_sub 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
	DECLARE 
		restricciones_operaciones_gru 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
			
		
	DECLARE 
		restricciones_operaciones_cap 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = 1;
		
			
		
	
	SET exit_loop = 0;
		
	OPEN restricciones_operaciones_4;
		
	bucle_4:
	LOOP
	
		FETCH 
			restricciones_operaciones_4 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_4;
			
		END IF;
		
		IF restriccion_operacion_aux=0 THEN
		
			RETURN 0;
			
		END IF;
		
		IF restriccion_operacion_aux=2 THEN
		
			 
			SET flag_restriccion_operacion_obligatoria = 
								ciex_check_restriccion_operacion_obligatoria(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			 
			SET flag_restriccion_operacion_puede_o_no_tener = 
								ciex_check_restriccion_operacion_puede_o_no_tener(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			IF flag_restriccion_operacion_obligatoria<>1 AND
				flag_restriccion_operacion_puede_o_no_tener<>3 THEN				 
		
				RETURN 2;
				
			END IF;
			
		END IF;
		
		
	END LOOP;
		
	CLOSE restricciones_operaciones_4;
	
	
	
	
	SET exit_loop = 0;
	
	OPEN restricciones_operaciones_3;
		
	bucle_3:
	LOOP
	
		FETCH 
			restricciones_operaciones_3 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_3;
			
		END IF;
		
		IF restriccion_operacion_aux=2 THEN
		
			 
			SET flag_restriccion_operacion_obligatoria = 
								ciex_check_restriccion_operacion_obligatoria(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			 
			SET flag_restriccion_operacion_puede_o_no_tener = 
								ciex_check_restriccion_operacion_puede_o_no_tener(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			IF flag_restriccion_operacion_obligatoria<>1 AND
				flag_restriccion_operacion_puede_o_no_tener<>3 THEN				 
		
				RETURN 2;
				
			END IF;
			
		END IF;
			
		IF restriccion_operacion_aux=0 THEN
		
			RETURN 0;
			
		END IF;
		
	END LOOP;
		
	CLOSE restricciones_operaciones_3;
	
	
	SET exit_loop = 0;
	
	
	
	
	OPEN restricciones_operaciones_sub;
		
	bucle_sub:
	LOOP
	
		FETCH 
			restricciones_operaciones_sub 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_sub;
			
		END IF;
		
		IF restriccion_operacion_aux=2 THEN
		
			 
			SET flag_restriccion_operacion_obligatoria = 
								ciex_check_restriccion_operacion_obligatoria(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			 
			SET flag_restriccion_operacion_puede_o_no_tener = 
								ciex_check_restriccion_operacion_puede_o_no_tener(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			IF flag_restriccion_operacion_obligatoria<>1 AND
				flag_restriccion_operacion_puede_o_no_tener<>3 THEN				 
		
				RETURN 2;
				
			END IF;
			
		END IF;
		
		IF restriccion_operacion_aux=0 THEN
		
			RETURN 0;
			
		END IF;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_sub;
	
	
	SET exit_loop = 0;
	
	
	
	
	
	OPEN restricciones_operaciones_gru;
		
	bucle_gru:
	LOOP
	
		FETCH 
			restricciones_operaciones_gru 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_gru;
			
		END IF;
		
		IF restriccion_operacion_aux=2 THEN
		
			 
			SET flag_restriccion_operacion_obligatoria = 
								ciex_check_restriccion_operacion_obligatoria(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			 
			SET flag_restriccion_operacion_puede_o_no_tener = 
								ciex_check_restriccion_operacion_puede_o_no_tener(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			IF flag_restriccion_operacion_obligatoria<>1 AND
				flag_restriccion_operacion_puede_o_no_tener<>3 THEN				 
		
				RETURN 2;
				
			END IF;
			
		END IF;
		
		IF restriccion_operacion_aux=0 THEN
		
			RETURN 0;
			
		END IF;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_gru;
	
	
	
	SET exit_loop = 0;
	
	
	
	
	OPEN restricciones_operaciones_cap;
		
	bucle_cap:
	LOOP
	
		FETCH 
			restricciones_operaciones_cap 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_cap;
			
		END IF;
		
		IF restriccion_operacion_aux=2 THEN
		
			 
			SET flag_restriccion_operacion_obligatoria = 
								ciex_check_restriccion_operacion_obligatoria(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			 
			SET flag_restriccion_operacion_puede_o_no_tener = 
								ciex_check_restriccion_operacion_puede_o_no_tener(
														cod_3dig,
														cod_4dig,
														fecha_vigencia);
														
			IF flag_restriccion_operacion_obligatoria<>1 AND
				flag_restriccion_operacion_puede_o_no_tener<>3 THEN				 
		
				RETURN 2;
				
			END IF;
			
		END IF;
		
		IF restriccion_operacion_aux=0 THEN
		
			RETURN 0;
			
		END IF;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_cap;
	
	
	
	RETURN 9;
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_str_split` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_str_split` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_str_split`(
							texto VARCHAR(255),
							delim VARCHAR(12),
							pos INT) RETURNS varchar(255) CHARSET latin1
    NO SQL
    DETERMINISTIC
    COMMENT 'Devuelve string segun delimitador y posicion'
BEGIN
		
	RETURN 
		REPLACE(
			SUBSTRING(
				SUBSTRING_INDEX(
							texto, 
							delim, 
							pos),
				LENGTH(
					SUBSTRING_INDEX(
								texto, 
								delim, 
								pos -1)
						) + 1
					),
			delim, 
			'');
END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_id_efector` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_id_efector` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_id_efector`(claveestd CHAR(8)) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Retorna id_efector'
BEGIN

	DECLARE aux_id INTEGER;
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			efectores e 
		WHERE 
			e.claveestd = claveestd);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	
	SET aux_id = 
	
		(SELECT 
			id_efector 
		FROM 
			efectores e
		WHERE 
			e.claveestd = claveestd);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	RETURN aux_id;

END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_id_efector_servicio` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_id_efector_servicio` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_id_efector_servicio`(id_efector INTEGER, id_servicio_estadistica INTEGER) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Calcula el id_efector_servicio'
BEGIN

	DECLARE aux_id INTEGER;
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			efectores e 
		WHERE 
			e.id_efector = id_efector);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	
	SET aux_id = 
	
		(SELECT 
			COUNT(*) 
		FROM 
			servicios_estadistica se 
		WHERE 
			se.id_servicio_estadistica = id_servicio_estadistica);
	
	IF aux_id=0 THEN
		
		RETURN -2;
		
	END IF;
	
	
	RETURN CONCAT(id_efector,LPAD(id_servicio_estadistica,3,'0'));

END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_id_servicio_sala` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_id_servicio_sala` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_id_servicio_sala`(id_sala INTEGER, id_servicio_estadistica INTEGER) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Retorna el id_servicio_sala'
BEGIN

	DECLARE aux_id INTEGER;
	
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			salas s 
		WHERE 
			s.id_sala = id_sala);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			servicios_estadistica se 
		WHERE 
			se.id_servicio_estadistica = id_servicio_estadistica);
	
	IF aux_id=0 THEN
		
		RETURN -2;
		
	END IF;
	
	
	RETURN CONCAT(id_sala,LPAD(id_servicio_estadistica,3,'0'));

END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_proximo_id_sala` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_proximo_id_sala` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_proximo_id_sala`(id_efector INTEGER) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Retorna el prox id_sala del efecto'
BEGIN

	DECLARE aux_id INTEGER;
	DECLARE cantidad SMALLINT;
	DECLARE nro_sala SMALLINT;
	
	
	SET nro_sala = servicios_get_proximo_nro_sala(id_efector);
	
	IF nro_sala = -1 THEN
	
		RETURN -1;
	
	END IF;
	
	
	RETURN CONCAT(id_efector,LPAD(nro_sala,3,'0'));

END */$$
DELIMITER ;

/* Function  structure for function  `ciex_check_restricciones_sexo` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_check_restricciones_sexo` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_check_restricciones_sexo`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							sexo TINYINT,
    							fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT 'TRUE=corresponde el sexo; FALSE=NO corresponde el sexo'
BEGIN
	DECLARE sexo_aux TINYINT;
	
	
	
	SET sexo_aux = 
		(SELECT 
			cr.sexo
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		IF (sexo_aux=1 AND sexo=2) OR (sexo_aux=2 AND sexo=1) THEN
		
			
			RETURN FALSE;
			
		ELSE
		
			
			RETURN TRUE;
			
		END IF;
		
	END IF;
	
	
	
	
	SET sexo_aux = 
		(SELECT 
			cr.sexo
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		IF (sexo_aux=1 AND sexo=2) OR (sexo_aux=2 AND sexo=1) THEN
		
			
			RETURN FALSE;
			
		ELSE
		
			
			RETURN TRUE;
			
		END IF;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			cr.sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		IF (sexo_aux=1 AND sexo=2) OR (sexo_aux=2 AND sexo=1) THEN
		
			
			RETURN FALSE;
			
		ELSE
		
			
			RETURN TRUE;
			
		END IF;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			cr.sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		IF (sexo_aux=1 AND sexo=2) OR (sexo_aux=2 AND sexo=1) THEN
		
			
			RETURN FALSE;
			
		ELSE
		
			
			RETURN TRUE;
			
		END IF;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			cr.sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		IF (sexo_aux=1 AND sexo=2) OR (sexo_aux=2 AND sexo=1) THEN
		
			
			RETURN FALSE;
			
		ELSE
		
			
			RETURN TRUE;
			
		END IF;
		
	END IF;
	
	
	RETURN TRUE;
	
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_es_diagnostico_defuncion` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_es_diagnostico_defuncion` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_es_diagnostico_defuncion`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT 'TRUE=defuncion; FALSE=no es defuncion'
BEGIN
	DECLARE defuncion_aux TINYINT;
	
	
	
	SET defuncion_aux = 
		(SELECT 
			defuncion
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF defuncion_aux IS NOT NULL THEN
	
		IF defuncion_aux=1 THEN
		
			
			RETURN TRUE;
			
		ELSE
		
			
			RETURN FALSE;
			
		END IF;
		
	END IF;
	
	
	
	
	SET defuncion_aux = 
		(SELECT 
			defuncion
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF defuncion_aux IS NOT NULL THEN
	
		IF defuncion_aux=1 THEN
		
			
			RETURN TRUE;
			
		ELSE
		
			
			RETURN FALSE;
			
		END IF;
		
	END IF;
	
	
	
	SET defuncion_aux = 
		(SELECT 
			defuncion
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF defuncion_aux IS NOT NULL THEN
	
		IF defuncion_aux=1 THEN
		
			
			RETURN TRUE;
			
		ELSE
		
			
			RETURN FALSE;
			
		END IF;
		
	END IF;
	
	
	
	SET defuncion_aux = 
		(SELECT 
			defuncion
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF defuncion_aux IS NOT NULL THEN
	
		IF defuncion_aux=1 THEN
		
			
			RETURN TRUE;
			
		ELSE
		
			
			RETURN FALSE;
			
		END IF;
		
	END IF;
	
	
	
	SET defuncion_aux = 
		(SELECT 
			defuncion
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF defuncion_aux IS NOT NULL THEN
	
		IF defuncion_aux=1 THEN
		
			
			RETURN TRUE;
			
		ELSE
		
			
			RETURN FALSE;
			
		END IF;
		
	END IF;
	
	
	RETURN FALSE;
	
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_check_restriccion_operacion_validacion` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_check_restriccion_operacion_validacion` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_check_restriccion_operacion_validacion`(
    								cod_3dig CHAR(3),
    								cod_4dig CHAR(4),
    								cod_operacion CHAR(4),
    								fecha_vigencia DATE) RETURNS tinyint(4)
    COMMENT '0=sin restr;1=oblig;2=no puede;3=puede o no;4=oblig RN;9=S/I'
BEGIN
	DECLARE	restriccion_operacion_aux TINYINT;
	DECLARE	cod_operacion_desde_aux CHAR(4);
	DECLARE	cod_operacion_hasta_aux CHAR(4);
	DECLARE exit_loop INT; 
	
	
	DECLARE 
		restricciones_operaciones_4
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion,
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
	DECLARE 
		restricciones_operaciones_3 
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion,
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
		
	DECLARE 
		restricciones_operaciones_sub 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion,
			cro.cod_operacion_desde, 
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
		
	DECLARE 
		restricciones_operaciones_gru 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion,
			cro.cod_operacion_desde, 
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
			
		
	DECLARE 
		restricciones_operaciones_cap 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion,
			cro.cod_operacion_desde, 
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = 1;
		
			
		
	
		
	
	
	
	SET exit_loop = 0;
		
	OPEN restricciones_operaciones_4;
		
	bucle_4:
	LOOP
	
		FETCH 
			restricciones_operaciones_4 
		INTO 
			restriccion_operacion_aux,
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_4;
			
		END IF;
		
		
		
		IF cod_operacion >= cod_operacion_desde_aux &&
			cod_operacion <= cod_operacion_hasta_aux THEN
			
			
			 
			
			
			
			RETURN restriccion_operacion_aux;
			
		END IF;
		
	END LOOP;
		
	CLOSE restricciones_operaciones_4;
	
	
	
	
	
	
	
	
	
	SET exit_loop = 0;
		
	OPEN restricciones_operaciones_3;
		
	bucle_3:
	LOOP
	
		FETCH 
			restricciones_operaciones_3 
		INTO 
			restriccion_operacion_aux,
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_3;
			
		END IF;
		
		
		IF cod_operacion >= cod_operacion_desde_aux &&
			cod_operacion <= cod_operacion_hasta_aux THEN
			
			
			 
			
			
			
			RETURN restriccion_operacion_aux;
			
		END IF;
		
	END LOOP;
		
	CLOSE restricciones_operaciones_3;
	
		
	
	
	
	
	
	SET exit_loop = 0;	
		
	OPEN restricciones_operaciones_sub;
		
	bucle_sub:
	LOOP
	
		FETCH 
			restricciones_operaciones_sub 
		INTO 
			restriccion_operacion_aux,
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_sub;
			
		END IF;
		
		
		IF cod_operacion >= cod_operacion_desde_aux &&
			cod_operacion <= cod_operacion_hasta_aux THEN
			
			
			 
			
			
			
			RETURN restriccion_operacion_aux;
			
		END IF;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_sub;
	
	
	
	
	
	
	
	SET exit_loop = 0;
		
	OPEN restricciones_operaciones_gru;
		
	bucle_gru:
	LOOP
	
		FETCH 
			restricciones_operaciones_gru 
		INTO 
			restriccion_operacion_aux,
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_gru;
			
		END IF;
		
		
		IF cod_operacion >= cod_operacion_desde_aux &&
			cod_operacion <= cod_operacion_hasta_aux THEN
			
			
			 
			
			
			
			RETURN restriccion_operacion_aux;
			
		END IF;
		
			
	END LOOP;
		
	CLOSE restricciones_operaciones_gru;
	
	
	
	
	
	
	
	SET exit_loop = 0;
		
	OPEN restricciones_operaciones_cap;
		
	bucle_cap:
	LOOP
	
		FETCH 
			restricciones_operaciones_cap 
		INTO 
			restriccion_operacion_aux,
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_cap;
			
		END IF;
		
		
		IF cod_operacion >= cod_operacion_desde_aux &&
			cod_operacion <= cod_operacion_hasta_aux THEN
			
			
			 
			
			
			
			RETURN restriccion_operacion_aux;
			
		END IF;
		
			
	END LOOP;
		
	CLOSE restricciones_operaciones_cap;
	
			
	
	
	RETURN 9;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_causa_externa` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_causa_externa` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_causa_externa`(
                                cod_3dig CHAR(3),
                                cod_4dig CHAR(4),
                                fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT '0=no es c.ext;1=es c.ext;2=como se produjo c.ext;3=no permitido'
BEGIN
    DECLARE causa_externa_aux TINYINT;
    
    
    
    SET causa_externa_aux = 
        (SELECT 
            causa_externa
        FROM
            ciex_restricciones cr
        WHERE
            cr.cod_3dig = cod_3dig
        AND cr.cod_4dig = cod_4dig
        AND cr.fecha_vigencia_desde <= fecha_vigencia 
        AND (cr.fecha_vigencia_hasta IS NULL 
            OR cr.fecha_vigencia_hasta >= fecha_vigencia)
        );
    
    IF causa_externa_aux IS NOT NULL THEN
    
        IF causa_externa_aux=0 THEN
        
            
            RETURN 0;
            
        END IF;
        
        IF causa_externa_aux=1 THEN
        
            
            RETURN 1;
            
        END IF;
        
        IF causa_externa_aux=2 THEN
        
            
            RETURN 2;
            
        END IF;
            
        IF causa_externa_aux=3 THEN
        
            
            RETURN 3;
            
        END IF;
        
        
        
    END IF;
    
    
    
    
    SET causa_externa_aux = 
        (SELECT 
            causa_externa
        FROM
            ciex_restricciones cr
        WHERE
            cr.cod_3dig = cod_3dig
        AND cr.id_ciex_4 IS NULL
        AND cr.fecha_vigencia_desde <= fecha_vigencia 
        AND (cr.fecha_vigencia_hasta IS NULL 
            OR cr.fecha_vigencia_hasta >= fecha_vigencia)
        );
    
    IF causa_externa_aux IS NOT NULL THEN
    
        IF causa_externa_aux=0 THEN
        
            
            RETURN 0;
            
        END IF;
        
        IF causa_externa_aux=1 THEN
        
            
            RETURN 1;
            
        END IF;
        
        IF causa_externa_aux=2 THEN
        
            
            RETURN 2;
            
        END IF;
            
        IF causa_externa_aux=3 THEN
        
            
            RETURN 3;
            
        END IF;
        
        
    END IF;
    
    
    
    SET causa_externa_aux = 
        (SELECT 
            causa_externa
        FROM
            ciex_restricciones cr
        INNER JOIN
            ciex_titulos ct
        ON
            cr.id_ciex_titulo = ct.id_ciex_titulo
        WHERE
            ct.cod_3dig_desde <= cod_3dig
        AND ct.cod_3dig_hasta >= cod_3dig
        AND ct.subgrupo<>'00'
        AND ct.grupo<>'00'
        AND ct.capitulo<>'00'
        AND cr.fecha_vigencia_desde <= fecha_vigencia 
        AND (cr.fecha_vigencia_hasta IS NULL 
            OR cr.fecha_vigencia_hasta >= fecha_vigencia)
        );
    
    IF causa_externa_aux IS NOT NULL THEN
    
        IF causa_externa_aux=0 THEN
        
            
            RETURN 0;
            
        END IF;
        
        IF causa_externa_aux=1 THEN
        
            
            RETURN 1;
            
        END IF;
        
        IF causa_externa_aux=2 THEN
        
            
            RETURN 2;
            
        END IF;
            
        IF causa_externa_aux=3 THEN
        
            
            RETURN 3;
            
        END IF;
        
        
    END IF;
    
    
    
    SET causa_externa_aux = 
        (SELECT 
            causa_externa
        FROM
            ciex_restricciones cr
        INNER JOIN
            ciex_titulos ct
        ON
            cr.id_ciex_titulo = ct.id_ciex_titulo
        WHERE
            ct.cod_3dig_desde <= cod_3dig
        AND ct.cod_3dig_hasta >= cod_3dig
        AND ct.subgrupo='00'
        AND ct.grupo<>'00'
        AND ct.capitulo<>'00'
        AND cr.fecha_vigencia_desde <= fecha_vigencia 
        AND (cr.fecha_vigencia_hasta IS NULL 
            OR cr.fecha_vigencia_hasta >= fecha_vigencia)
        );
    
    IF causa_externa_aux IS NOT NULL THEN
    
        IF causa_externa_aux=0 THEN
        
            
            RETURN 0;
            
        END IF;
        
        IF causa_externa_aux=1 THEN
        
            
            RETURN 1;
            
        END IF;
        
        IF causa_externa_aux=2 THEN
        
            
            RETURN 2;
            
        END IF;
            
        IF causa_externa_aux=3 THEN
        
            
            RETURN 3;
            
        END IF;
          
        
        
    END IF;
    
    
    SET causa_externa_aux = 
        (SELECT 
            causa_externa
        FROM
            ciex_restricciones cr
        INNER JOIN
            ciex_titulos ct
        ON
            cr.id_ciex_titulo = ct.id_ciex_titulo
        WHERE
            ct.cod_3dig_desde <= cod_3dig
        AND ct.cod_3dig_hasta >= cod_3dig
        AND ct.subgrupo='00'
        AND ct.grupo='00'
        AND ct.capitulo<>'00'
        AND cr.fecha_vigencia_desde <= fecha_vigencia 
        AND (cr.fecha_vigencia_hasta IS NULL 
            OR cr.fecha_vigencia_hasta >= fecha_vigencia)
        );
    
    IF causa_externa_aux IS NOT NULL THEN
    
        IF causa_externa_aux=0 THEN
        
            
            RETURN 0;
            
        END IF;
        
        IF causa_externa_aux=1 THEN
        
            
            RETURN 1;
            
        END IF;
        
        IF causa_externa_aux=2 THEN
        
            
            RETURN 2;
            
        END IF;
            
        IF causa_externa_aux=3 THEN
        
            
            RETURN 3;
            
        END IF;
        
        
        
    END IF;
    
    
    
    RETURN 9;
    
    
    
    
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_frecuencia` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_frecuencia` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_frecuencia`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT '0=OK,1=poco frec;2=no codif;3=asterisc;4=daga;5=solo CE'
BEGIN

	DECLARE frecuencia_aux TINYINT;
	
	
	
	SET frecuencia_aux = 
		(SELECT 
			frecuencia
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF frecuencia_aux IS NOT NULL THEN
	
		
		
		
		
		
		
		IF frecuencia_aux<6 THEN
		
			RETURN frecuencia_aux;
			
		END IF;
		
	END IF;
		
	
	
	
	SET frecuencia_aux = 
		(SELECT 
			frecuencia
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF frecuencia_aux IS NOT NULL THEN
	
		
		
		
		
		
		
		IF frecuencia_aux<6 THEN
		
			RETURN frecuencia_aux;
			
		END IF;
		
		
	END IF;
		
	
	
	SET frecuencia_aux = 
		(SELECT 
			frecuencia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF frecuencia_aux IS NOT NULL THEN
	
		
		
		
		
		
		
		IF frecuencia_aux<6 THEN
		
			RETURN frecuencia_aux;
			
		END IF;
		
	END IF;
		
	
	
	
	
	SET frecuencia_aux = 
		(SELECT 
			frecuencia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF frecuencia_aux IS NOT NULL THEN
	
		
		
		
		
		
		
		IF frecuencia_aux<6 THEN
		
			RETURN frecuencia_aux;
			
		END IF;
		
	END IF;
	
	
	
	
	SET frecuencia_aux = 
		(SELECT 
			frecuencia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia) 
		);
	
	IF frecuencia_aux IS NOT NULL THEN
	
		
		
		
		
		
		
		IF frecuencia_aux<6 THEN
		
			RETURN frecuencia_aux;
			
		END IF;
		
	END IF;
	
	
	RETURN 0;
	
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_restricciones_sexo` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_restricciones_sexo` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_restricciones_sexo`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT '0=no tiene;1=solo masc;2=solo fem'
BEGIN
	DECLARE sexo_aux TINYINT;
	
	
	
	SET sexo_aux = 
		(SELECT 
			sexo
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		
		RETURN sexo_aux;
		
	END IF;
	
	
	
	
	SET sexo_aux = 
		(SELECT 
			sexo
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		
		RETURN sexo_aux;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		
		RETURN sexo_aux;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		
		RETURN sexo_aux;
		
	END IF;
	
	
	
	SET sexo_aux = 
		(SELECT 
			sexo
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF sexo_aux IS NOT NULL THEN
	
		
		RETURN sexo_aux;
		
	END IF;
	
	
	RETURN 0;
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_obstetricia` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_obstetricia` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_obstetricia`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(1)
    COMMENT '0=no;1=par;2=sn par;3=ab;4=sn ab;5=no-p;6=par-p;7=sn par-p;9=S/I'
BEGIN

	DECLARE obstetricia_aux TINYINT;
	
	
	
	SET obstetricia_aux = 
		(SELECT 
			obstetricia
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF obstetricia_aux IS NOT NULL THEN
	
		IF obstetricia_aux=0 THEN
		
			
			RETURN 0;
			
		END IF;
		
		IF obstetricia_aux=1 THEN
		
			
			RETURN 1;
			
		END IF;
		
		IF obstetricia_aux=2 THEN
		
			
			RETURN 2;
			
		END IF;
			
		IF obstetricia_aux=3 THEN
		
			
			RETURN 3;
			
		END IF;
		
		IF obstetricia_aux=4 THEN
		
			
			RETURN 4;
			
		END IF;
		
		IF obstetricia_aux=5 THEN
		
			
			RETURN 5;
			
		END IF;
				
		IF obstetricia_aux=6 THEN
		
			
			RETURN 6;
			
		END IF;
		
		IF obstetricia_aux=7 THEN
		
			
			RETURN 7;
			
		END IF;
		
		IF obstetricia_aux=9 THEN
		
			
			RETURN 9;
			
		END IF;
		
	END IF;
	
	
	
	
	SET obstetricia_aux = 
		(SELECT 
			obstetricia
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF obstetricia_aux IS NOT NULL THEN
	
		IF obstetricia_aux=0 THEN
		
			
			RETURN 0;
			
		END IF;
		
		IF obstetricia_aux=1 THEN
		
			
			RETURN 1;
			
		END IF;
		
		IF obstetricia_aux=2 THEN
		
			
			RETURN 2;
			
		END IF;
			
		IF obstetricia_aux=3 THEN
		
			
			RETURN 3;
			
		END IF;
		
		IF obstetricia_aux=4 THEN
		
			
			RETURN 4;
			
		END IF;
		
		IF obstetricia_aux=5 THEN
		
			
			RETURN 5;
			
		END IF;
				
		IF obstetricia_aux=6 THEN
		
			
			RETURN 6;
			
		END IF;
		
		IF obstetricia_aux=7 THEN
		
			
			RETURN 7;
			
		END IF;
		
		IF obstetricia_aux=9 THEN
		
			
			RETURN 9;
			
		END IF;
			
		
		
	END IF;
	
	
	
	SET obstetricia_aux = 
		(SELECT 
			obstetricia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF obstetricia_aux IS NOT NULL THEN
	
		IF obstetricia_aux=0 THEN
		
			
			RETURN 0;
			
		END IF;
		
		IF obstetricia_aux=1 THEN
		
			
			RETURN 1;
			
		END IF;
		
		IF obstetricia_aux=2 THEN
		
			
			RETURN 2;
			
		END IF;
			
		IF obstetricia_aux=3 THEN
		
			
			RETURN 3;
			
		END IF;
		
		IF obstetricia_aux=4 THEN
		
			
			RETURN 4;
			
		END IF;
		
		IF obstetricia_aux=5 THEN
		
			
			RETURN 5;
			
		END IF;
				
		IF obstetricia_aux=6 THEN
		
			
			RETURN 6;
			
		END IF;
		
		IF obstetricia_aux=7 THEN
		
			
			RETURN 7;
			
		END IF;
		
		IF obstetricia_aux=9 THEN
		
			
			RETURN 9;
			
		END IF;
			
		
		
	END IF;
	
	
	
	SET obstetricia_aux = 
		(SELECT 
			obstetricia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF obstetricia_aux IS NOT NULL THEN
	
		IF obstetricia_aux=0 THEN
		
			
			RETURN 0;
			
		END IF;
		
		IF obstetricia_aux=1 THEN
		
			
			RETURN 1;
			
		END IF;
		
		IF obstetricia_aux=2 THEN
		
			
			RETURN 2;
			
		END IF;
			
		IF obstetricia_aux=3 THEN
		
			
			RETURN 3;
			
		END IF;
		
		IF obstetricia_aux=4 THEN
		
			
			RETURN 4;
			
		END IF;
		
		IF obstetricia_aux=5 THEN
		
			
			RETURN 5;
			
		END IF;
				
		IF obstetricia_aux=6 THEN
		
			
			RETURN 6;
			
		END IF;
		
		IF obstetricia_aux=7 THEN
		
			
			RETURN 7;
			
		END IF;
		
		IF obstetricia_aux=9 THEN
		
			
			RETURN 9;
			
		END IF;
			
		
		
	END IF;
	
	
	SET obstetricia_aux = 
		(SELECT 
			obstetricia
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	IF obstetricia_aux IS NOT NULL THEN
	
		IF obstetricia_aux=0 THEN
		
			
			RETURN 0;
			
		END IF;
		
		IF obstetricia_aux=1 THEN
		
			
			RETURN 1;
			
		END IF;
		
		IF obstetricia_aux=2 THEN
		
			
			RETURN 2;
			
		END IF;
			
		IF obstetricia_aux=3 THEN
		
			
			RETURN 3;
			
		END IF;
		
		IF obstetricia_aux=4 THEN
		
			
			RETURN 4;
			
		END IF;
		
		IF obstetricia_aux=5 THEN
		
			
			RETURN 5;
			
		END IF;
				
		IF obstetricia_aux=6 THEN
		
			
			RETURN 6;
			
		END IF;
		
		IF obstetricia_aux=7 THEN
		
			
			RETURN 7;
			
		END IF;
		
		IF obstetricia_aux=9 THEN
		
			
			RETURN 9;
			
		END IF;
			
		
		
	END IF;
	
	
	
	RETURN 9;
	
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_rangos_operaciones_diagnostico` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_rangos_operaciones_diagnostico` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_rangos_operaciones_diagnostico`(
    								cod_3dig CHAR(3),
    								cod_4dig CHAR(4),
    								restriccion_operacion TINYINT,
    								fecha_vigencia DATE) RETURNS varchar(255) CHARSET latin1
    COMMENT 'Devuelve string con rangos de oper'
BEGIN
	DECLARE rangos_aux VARCHAR(255);
	DECLARE cod_operacion_desde_aux CHAR(4);
	DECLARE cod_operacion_hasta_aux CHAR(4);
	
	DECLARE exit_loop INT; 
		
	
	DECLARE 
		rangos_operaciones_4
	CURSOR FOR 
		(SELECT 
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		AND cro.restriccion_operacion = restriccion_operacion
		);
		
	
	
	DECLARE 
		rangos_operaciones_3
	CURSOR FOR 
		(SELECT 
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		AND cro.restriccion_operacion = restriccion_operacion
		);
		
	
	DECLARE 
		rangos_operaciones_subgrupo
	CURSOR FOR 
		(SELECT 
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		AND cro.restriccion_operacion = restriccion_operacion
		);
		
	
	DECLARE 
		rangos_operaciones_grupo
	CURSOR FOR 
		(SELECT 
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		AND cro.restriccion_operacion = restriccion_operacion
		);
				
	
	DECLARE 
		rangos_operaciones_titulos
	CURSOR FOR 
		(SELECT 
			cro.cod_operacion_desde,
			cro.cod_operacion_hasta
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		AND cro.restriccion_operacion = restriccion_operacion
		);
		
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = 1;	
	
	
	
	
	
	SET rangos_aux='';
	
	
	
	SET exit_loop = 0;
	
	OPEN rangos_operaciones_4;
		
	bucle_4:
	LOOP
	
		FETCH 
			rangos_operaciones_4 
		INTO 
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_4;
			
		END IF;
		
		
		SET rangos_aux = CONCAT(rangos_aux,cod_operacion_desde_aux,'-',cod_operacion_hasta_aux,' ');
	
	END LOOP;
		
	CLOSE rangos_operaciones_4;
	
	
	IF rangos_aux<>'' THEN
	
		RETURN rangos_aux;
		
	END IF;
	
	
	
	
	SET exit_loop = 0;
	
	OPEN rangos_operaciones_3;
		
	bucle_3:
	LOOP
	
		FETCH 
			rangos_operaciones_3 
		INTO 
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_3;
			
		END IF;
		
		
		SET rangos_aux = CONCAT(rangos_aux,cod_operacion_desde_aux,'-',cod_operacion_hasta_aux,' ');
	
	END LOOP;
		
	CLOSE rangos_operaciones_3;
	
	
	
	IF rangos_aux<>'' THEN
	
		RETURN rangos_aux;
		
	END IF;
	
	
	
	SET exit_loop = 0;
	
	OPEN rangos_operaciones_subgrupo;
		
	bucle_subgrupo:
	LOOP
	
		FETCH 
			rangos_operaciones_subgrupo 
		INTO 
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_subgrupo;
			
		END IF;
		
		
		SET rangos_aux = CONCAT(rangos_aux,cod_operacion_desde_aux,'-',cod_operacion_hasta_aux,' ');
	
	END LOOP;
		
	CLOSE rangos_operaciones_subgrupo;
	
	
	
	IF rangos_aux<>'' THEN
	
		RETURN rangos_aux;
		
	END IF;
	
	
	
	SET exit_loop = 0;
	
	OPEN rangos_operaciones_grupo;
		
	bucle_grupo:
	LOOP
	
		FETCH 
			rangos_operaciones_grupo 
		INTO 
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_grupo;
			
		END IF;
		
		
		SET rangos_aux = CONCAT(rangos_aux,cod_operacion_desde_aux,'-',cod_operacion_hasta_aux,' ');
	
	END LOOP;
		
	CLOSE rangos_operaciones_grupo;
	
	
	
	IF rangos_aux<>'' THEN
	
		RETURN rangos_aux;
		
	END IF;
	
	
	
	SET exit_loop = 0;
	
	OPEN rangos_operaciones_titulos;
		
	bucle_titulos:
	LOOP
	
		FETCH 
			rangos_operaciones_titulos 
		INTO 
			cod_operacion_desde_aux,
			cod_operacion_hasta_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_titulos;
			
		END IF;
		
		
		SET rangos_aux = CONCAT(rangos_aux,cod_operacion_desde_aux,'-',cod_operacion_hasta_aux,' ');
	
	END LOOP;
		
	CLOSE rangos_operaciones_titulos;
	
	
	
	
	RETURN rangos_aux;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `ciex_get_restriccion_operacion` */

/*!50003 DROP FUNCTION IF EXISTS `ciex_get_restriccion_operacion` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `ciex_get_restriccion_operacion`(
    							cod_3dig CHAR(3),
    							cod_4dig CHAR(4),
    							fecha_vigencia DATE) RETURNS tinyint(4)
    DETERMINISTIC
    COMMENT '0:sin restr;1=oblig;2=no puede;3=puedo o no;4=oblig rn;9=S/I'
BEGIN
	DECLARE	restriccion_operacion_aux TINYINT;
	DECLARE retorno TINYINT;
	DECLARE exit_loop INT; 
	
	
	DECLARE 
		restricciones_operaciones_4
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cr.id_ciex_restriccion = cro.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.cod_4dig = cod_4dig
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
	DECLARE 
		restricciones_operaciones_3 
	CURSOR FOR 
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
	
	
		
	DECLARE 
		restricciones_operaciones_sub 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
	DECLARE 
		restricciones_operaciones_gru 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
			
		
	DECLARE 
		restricciones_operaciones_cap 
	CURSOR FOR
		(SELECT 
			cro.restriccion_operacion
		FROM
			ciex_restricciones_operaciones cro
		INNER JOIN
			ciex_restricciones cr
		ON
			cro.id_ciex_restriccion = cr.id_ciex_restriccion
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = 1;
		
			
		
	
	SET exit_loop = 0;
	SET retorno = 9;
	
	OPEN restricciones_operaciones_4;
		
	bucle_4:
	LOOP
	
		FETCH 
			restricciones_operaciones_4 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_4;
			
		END IF;
		
		RETURN restriccion_operacion_aux;
				
	END LOOP;
		
	CLOSE restricciones_operaciones_4;
	
	
	
	
	SET exit_loop = 0;
	
	OPEN restricciones_operaciones_3;
		
	bucle_3:
	LOOP
	
		FETCH 
			restricciones_operaciones_3 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_3;
			
		END IF;
		
		RETURN restriccion_operacion_aux; 
				
	END LOOP;
		
	CLOSE restricciones_operaciones_3;
	
	
	SET exit_loop = 0;
	
	
	
	
	OPEN restricciones_operaciones_sub;
		
	bucle_sub:
	LOOP
	
		FETCH 
			restricciones_operaciones_sub 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_sub;
			
		END IF;
		
		RETURN restriccion_operacion_aux;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_sub;
	
	
	SET exit_loop = 0;
	
	
	
	
	
	OPEN restricciones_operaciones_gru;
		
	bucle_gru:
	LOOP
	
		FETCH 
			restricciones_operaciones_gru 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_gru;
			
		END IF;
		
		RETURN restriccion_operacion_aux;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_gru;
	
	
	
	SET exit_loop = 0;
	
	
	
	
	OPEN restricciones_operaciones_cap;
		
	bucle_cap:
	LOOP
	
		FETCH 
			restricciones_operaciones_cap 
		INTO 
			restriccion_operacion_aux;
			
		IF exit_loop=1 THEN
		
			LEAVE bucle_cap;
			
		END IF;
		
		RETURN restriccion_operacion_aux;
			
	END LOOP;
		
	CLOSE restricciones_operaciones_cap;
	
	
	
	RETURN 9;
	
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_int_edad` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_int_edad` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_int_edad`(fecha DATETIME) RETURNS int(11)
    READS SQL DATA
    COMMENT 'Devuelve INTEGER con la edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora DATETIME;
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora = CONCAT(aux_fecha,' ',TIME(fecha));
	
	
	IF aux_fecha_hora = NOW() OR
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))>=0 ) THEN
	
		RETURN 0;
		
	END IF;
	
					
	
	SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora,NOW()));
	IF anios<>0 THEN 
	
		RETURN anios;
			
	END IF;
	
	
	SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora,NOW()));
	IF meses<>0 THEN
	
		RETURN meses;
		
	END IF;
	
	
	SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora,NOW()));
	IF dias<>0 THEN
		
		RETURN dias;
		
	END IF;
	
	
	SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora,NOW()));
	IF horas<>0 THEN
	
		RETURN horas;
		
	END IF;
	
	
	SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora,NOW()));
	IF minutos<>0 THEN
	
		RETURN minutos;
		
	END IF;
	
	RETURN NULL;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_int_edad2` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_int_edad2` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_int_edad2`(fecha DATETIME, tipo_edad INTEGER) RETURNS int(11)
    READS SQL DATA
    COMMENT 'Devuelve INTEGER con la edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora DATETIME;
	
	
	IF tipo_edad<1 OR tipo_edad>5 THEN
	
		RETURN NULL;
		
	END IF;
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora = CONCAT(aux_fecha,' ',TIME(fecha));
	
	
	IF aux_fecha_hora = NOW() OR 
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))>=0 ) THEN
	
		RETURN 0;
			
	END IF;
	
					
	
	IF tipo_edad=1 THEN
	
		SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora,NOW()));
	
		RETURN anios;
			
	END IF;
	
	
	IF tipo_edad=2 THEN
	
		SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora,NOW()));
	
		RETURN meses;
		
	END IF;
	
	
	IF tipo_edad=3 THEN
		
		SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora,NOW()));
			
		RETURN dias;
		
	END IF;
	
	
	IF tipo_edad=4 THEN
	
		SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora,NOW()));
		
		RETURN horas;
		
	END IF;
	
	
	IF tipo_edad=5 THEN
	
		SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora,NOW()));
		
		RETURN minutos;
		
	END IF;
	
	RETURN NULL;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_int_edad_diff_fecha` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_int_edad_diff_fecha` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_int_edad_diff_fecha`(fecha_desde DATETIME, fecha_hasta DATETIME) RETURNS int(11)
    READS SQL DATA
    COMMENT 'Devuelve INTEGER con la diff calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora_desde DATETIME;
	DECLARE aux_fecha_hora_hasta DATETIME;
	
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha_desde)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora_desde = CONCAT(aux_fecha,' ',TIME(fecha_desde));
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha_hasta)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora_hasta = CONCAT(aux_fecha,' ',TIME(fecha_hasta));
	
	
	
	IF aux_fecha_hora_desde = aux_fecha_hora_hasta OR
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora_desde,aux_fecha_hora_hasta))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora_desde,aux_fecha_hora_hasta))>=0 ) THEN
	
		RETURN 0;
			
	END IF;
	
					
	
	SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF anios<>0 THEN 
	
		RETURN anios;
			
	END IF;
	
	
	SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF meses<>0 THEN
	
		RETURN meses;
		
	END IF;
	
	
	SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF dias<>0 THEN
		
		RETURN dias;
		
	END IF;
	
	
	SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF horas<>0 THEN
	
		RETURN horas;
		
	END IF;
	
	
	SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF minutos<>0 THEN
	
		RETURN minutos;
		
	END IF;
	
	RETURN NULL;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_int_tipo_edad` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_int_tipo_edad` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_int_tipo_edad`(fecha DATETIME) RETURNS int(11)
    READS SQL DATA
    COMMENT 'Devuelve INTEGER con el tipo de edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora DATETIME;
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora = CONCAT(aux_fecha,' ',TIME(fecha));
			
	
	IF aux_fecha_hora = NOW() OR 
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))>=0 ) THEN
	
		RETURN 5;
			
	END IF;
			
	
	SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora,NOW()));
	IF anios<>0 THEN 
	
		RETURN 1;
			
	END IF;
	
	
	SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora,NOW()));
	IF meses<>0 THEN
	
		RETURN 2;
		
	END IF;
	
	
	SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora,NOW()));
	IF dias<>0 THEN
		
		RETURN 3;
		
	END IF;
	
	
	SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora,NOW()));
	IF horas<>0 THEN
	
		RETURN 4;
		
	END IF;
	
	
	SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora,NOW()));
	IF minutos<>0 THEN
	
		RETURN 5;
		
	END IF;
	
	RETURN 6;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_int_tipo_edad_diff_fecha` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_int_tipo_edad_diff_fecha` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_int_tipo_edad_diff_fecha`(fecha_desde DATETIME, fecha_hasta DATETIME) RETURNS int(11)
    READS SQL DATA
    COMMENT 'Devuelve INTEGER con el tipo de edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora_desde DATETIME;
	DECLARE aux_fecha_hora_hasta DATETIME;
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha_desde)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora_desde = CONCAT(aux_fecha,' ',TIME(fecha_desde));
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha_hasta)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora_hasta = CONCAT(aux_fecha,' ',TIME(fecha_hasta));
	
	
	
	IF aux_fecha_hora_desde = aux_fecha_hora_hasta OR
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora_desde,aux_fecha_hora_hasta))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora_desde,aux_fecha_hora_hasta))>=0 ) THEN
	
		RETURN 5;
			
	END IF;
	
					
	
	SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF anios<>0 THEN 
	
		RETURN 1;
			
	END IF;
	
	
	SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF meses<>0 THEN
	
		RETURN 2;
		
	END IF;
	
	
	SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF dias<>0 THEN
		
		RETURN 3;
		
	END IF;
	
	
	SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF horas<>0 THEN
	
		RETURN 4;
		
	END IF;
	
	
	SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora_desde,aux_fecha_hora_hasta));
	IF minutos<>0 THEN
	
		RETURN 5;
		
	END IF;
	
	RETURN 6;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_separa_ape` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_separa_ape` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_separa_ape`(ape_nom VARCHAR(255), tipo BOOLEAN) RETURNS varchar(255) CHARSET latin1
    NO SQL
    DETERMINISTIC
    COMMENT 'Devuelve apellido/nombre de STRING ape_nom'
BEGIN
	DECLARE ape VARCHAR(255) DEFAULT '';
	DECLARE nom VARCHAR(255) DEFAULT '';
	DECLARE aux_ape_nom VARCHAR(255);
	DECLARE aux_char CHAR(1);
	DECLARE aux_i SMALLINT DEFAULT 1;
	DECLARE indice SMALLINT DEFAULT 1;
	
	
	IF ISNULL(ape_nom) THEN 
		RETURN NULL; 
	END IF;
	
	
	SET ape_nom = TRIM(REPLACE(ape_nom,","," "));
	
	
	SET ape_nom = TRIM(REPLACE(ape_nom,"."," "));
	
	
	SET ape_nom = TRIM(REPLACE(ape_nom,"*"," "));
	
	
	SET aux_ape_nom = UPPER(ape_nom);
	
	
	SET aux_i = 1;
	
	WHILE aux_i < LENGTH(aux_ape_nom) DO
	
		SET aux_char = SUBSTRING(aux_ape_nom,aux_i,1);
		
		IF aux_char=" " THEN
		
			IF SUBSTRING(aux_ape_nom,aux_i+1,1) = " " THEN
			
				SET aux_ape_nom = CONCAT(SUBSTRING(aux_ape_nom,
												1,
												aux_i),
									SUBSTRING(aux_ape_nom,
												aux_i+2,
												LENGTH(aux_ape_nom))
									);
				
			ELSE
				SET aux_i = aux_i + 1;
				
			END IF;
			
		ELSE
			SET aux_i = aux_i + 1;
		END IF;
	
	END WHILE;
	
	
	SET ape_nom = aux_ape_nom;
	
	
	SET ape = SUBSTRING_INDEX(aux_ape_nom," ",1);
	
	
	IF LENGTH(ape)<3 THEN
		SET indice=2;
	END IF;
	
	
	IF	ape = "VON" 	OR
		ape = "SANTA"	OR
		ape = "DAL" 	OR
		ape = "DEL" 	OR
		ape = "VAN" 	OR
		ape = "SAN" 	OR
		ape = "MAC" 	OR
		ape = "DOS" 	OR
		ape = "DAS" 
		THEN
		SET indice=2;
	END IF;
	
	
	SET ape = SUBSTRING_INDEX(aux_ape_nom," ",2);
		
	
	IF	ape = "DE LA" 		OR 
		ape = "VON DER" 	OR
		ape = "DE LOS" 		OR
		ape = "PONCE DE"
		THEN
		SET indice=3;
	END IF;
	
	
	SET ape = SUBSTRING_INDEX(ape_nom," ",indice);
	SET indice = LENGTH(ape)+2;
	SET nom = SUBSTRING(ape_nom,indice);
	
	
	IF tipo THEN
		RETURN TRIM(ape);
	ELSE
		RETURN TRIM(nom);
	END IF;
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_str_edad` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_str_edad` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_str_edad`(fecha DATETIME) RETURNS varchar(255) CHARSET latin1
    READS SQL DATA
    COMMENT 'Devuelve un STRING con la edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora DATETIME;
	
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora = CONCAT(aux_fecha,' ',TIME(fecha));
	
	
	IF aux_fecha_hora = NOW() OR
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))>=0 ) THEN
	
		RETURN '0 minutos';
		
	END IF;
	
					
	
	SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora,NOW()));
	IF anios<>0 THEN 
	
		IF anios=1 THEN
		
			RETURN '1 a�o';
			
		ELSE
			
			IF anios<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(anios,' a�os');
				
			END IF;
			
		END IF;
		
		
	END IF;
	
	
	SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora,NOW()));
	IF meses<>0 THEN
	
		IF meses=1 THEN
		
			RETURN '1 mes';
			
		ELSE
			
			IF meses<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(meses,' meses');
			
			END IF;
			
		END IF;
		
	END IF;
	
	
	SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora,NOW()));
	IF dias<>0 THEN
	
		IF dias=1 THEN
		
			RETURN '1 d�a';
			
		ELSE
			
			IF dias<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(dias,' d�as');
			
			END IF;
			
		END IF;
		
	END IF;
	
	
	SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora,NOW()));
	IF horas<>0 THEN
	
		IF horas=1 THEN
		
			RETURN '1 hora';
			
		ELSE
			
			IF horas<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(horas,' horas');
				
			END IF;
			
		END IF;
		
	END IF;
	
	
	SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora,NOW()));
	IF minutos<>0 THEN
	
		IF minutos=1 THEN
		
			RETURN '1 minuto';
			
		ELSE
			
			IF minutos<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(minutos,' minutos');
				
			END IF;
			
		END IF;
		
	END IF;
	
	RETURN 'ignorado';
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_str_edad2` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_str_edad2` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_str_edad2`(fecha DATETIME, tipo_edad INTEGER) RETURNS varchar(255) CHARSET latin1
    READS SQL DATA
    COMMENT 'Devuelve un STRING con la edad calculada'
BEGIN
	DECLARE anios INTEGER;
	DECLARE meses INTEGER;
	DECLARE dias INTEGER;
	DECLARE horas INTEGER;
	DECLARE minutos INTEGER;
	
	DECLARE aux_fecha DATE;
	DECLARE aux_fecha_hora DATETIME;
	
	
	IF tipo_edad<1 OR tipo_edad>5 THEN
	
		RETURN 'El tipo de edad debe ser un valor entre 1 y 5';
		
	END IF;
	
	
	SET aux_fecha = (SELECT hmi2_valida_fecha_nac(DATE(fecha)));
	IF aux_fecha = '0000-00-00' OR 
		aux_fecha IS NULL 
		THEN RETURN NULL;
		
	END IF;
	SET aux_fecha_hora = CONCAT(aux_fecha,' ',TIME(fecha));
					
	
	
	IF aux_fecha_hora = NOW() OR
		( (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))<60 
		AND (SELECT TIMESTAMPDIFF(SECOND,aux_fecha_hora,NOW()))>=0 ) THEN
	
		CASE tipo_edad
		
			WHEN 1 THEN RETURN '0 a�os';
			WHEN 2 THEN RETURN '0 meses';
			WHEN 3 THEN RETURN '0 dias';
			WHEN 4 THEN RETURN '0 horas';
			WHEN 5 THEN RETURN '0 minutos';
			
			ELSE RETURN '0 minutos';
			
		END CASE;
		
	END IF;
	
	
	
	IF tipo_edad=1 THEN
	
		SET anios = (SELECT TIMESTAMPDIFF(YEAR,aux_fecha_hora,NOW()));
		
		IF anios=1 THEN
		
			RETURN '1 a�o';
			
		ELSE
			
			IF anios<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(anios,' a�os');
				
			END IF;
			
		END IF;
		
	END IF;
	
	
	
	IF tipo_edad=2 THEN
	
		SET meses = (SELECT TIMESTAMPDIFF(MONTH,aux_fecha_hora,NOW()));
	
		IF meses=1 THEN
		
			RETURN '1 mes';
			
		ELSE
			
			IF meses<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(meses,' meses');
			
			END IF;
			
		END IF;
		
	END IF;
	
	
	IF tipo_edad=3 THEN
	
		SET dias = (SELECT TIMESTAMPDIFF(DAY,aux_fecha_hora,NOW()));
	
		IF dias=1 THEN
		
			RETURN '1 d�a';
			
		ELSE
			
			IF dias<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(dias,' d�as');
			
			END IF;
			
		END IF;
		
	END IF;
	
	
	
	
	IF tipo_edad=4 THEN
	
		SET horas = (SELECT TIMESTAMPDIFF(HOUR,aux_fecha_hora,NOW()));
	
		IF horas=1 THEN
		
			RETURN '1 hora';
			
		ELSE
			
			IF horas<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(horas,' horas');
				
			END IF;
			
		END IF;
		
	END IF;
	
	
	
	
	IF tipo_edad=5 THEN
	
		SET minutos = (SELECT TIMESTAMPDIFF(MINUTE,aux_fecha_hora,NOW()));
	
		IF minutos=1 THEN
		
			RETURN '1 minuto';
			
		ELSE
			
			IF minutos<0 THEN
				
				RETURN NULL;
				
			ELSE
			
				RETURN CONCAT(minutos,' minutos');
				
			END IF;
			
		END IF;
		
	END IF;
	
	RETURN 'ignorado';
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `hmi2_valida_fecha_nac` */

/*!50003 DROP FUNCTION IF EXISTS `hmi2_valida_fecha_nac` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `hmi2_valida_fecha_nac`(fecha DATE) RETURNS date
    READS SQL DATA
    COMMENT 'Valida el aÃ±o y controla contra fecha actual'
BEGIN
	DECLARE anio CHAR(4);
	DECLARE rango_desde TINYINT;
	DECLARE rango_hasta TINYINT;
	DECLARE aux_fecha DATE;
	DECLARE aux_now DATE;
	
	
	
	
	SET rango_desde = 70;
	SET rango_hasta = 99;
	
	
	IF fecha='0000-00-00' OR
		fecha IS NULL THEN
			RETURN fecha;
	END IF;
	
	
	
	IF YEAR(fecha)<10 THEN
	
		SET anio = CONCAT('200',YEAR(fecha));
		
	ELSE
		
		IF YEAR(fecha)<=rango_hasta 
			AND YEAR(fecha)>=rango_desde THEN
			
			SET anio = CONCAT('19',YEAR(fecha));
			
		ELSE
			
			SET anio = YEAR(fecha);
			
		END IF;
		
	END IF;
	
	SET aux_fecha = DATE_FORMAT ( CONCAT(anio,'-',MONTH(fecha),'-',DAY(fecha)), '%Y-%m-%d');
	SET aux_now=DATE(NOW());
	
	IF aux_fecha>DATE(NOW()) THEN
	
		SET anio = CONCAT('19',RIGHT(anio,2));
		
	END IF;
	
	
	RETURN DATE_FORMAT ( CONCAT(anio,'-',MONTH(fecha),'-',DAY(fecha)), '%Y-%m-%d');
	
END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_id_servicio_estadistica` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_id_servicio_estadistica` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_id_servicio_estadistica`(
		cod_servicio CHAR(3),
		sector CHAR(1),
		subsector CHAR(1)) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Retorna id_servicio_estadistica'
BEGIN

	DECLARE aux_id INTEGER;
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			servicios_estadistica se 
		WHERE 
			se.cod_servicio = cod_servicio
		AND se.sector = sector
		AND se.subsector = subsector);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	
	SET aux_id = 
	
		(SELECT 
			id_servicio_estadistica
		FROM 
			servicios_estadistica se 
		WHERE 
			se.cod_servicio = cod_servicio
		AND se.sector = sector
		AND se.subsector = subsector);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	RETURN aux_id;

END */$$
DELIMITER ;

/* Function  structure for function  `servicios_get_proximo_nro_sala` */

/*!50003 DROP FUNCTION IF EXISTS `servicios_get_proximo_nro_sala` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `servicios_get_proximo_nro_sala`(id_efector INTEGER) RETURNS int(11)
    DETERMINISTIC
    COMMENT 'Retorna el prox nro sala del efector'
BEGIN

	DECLARE aux_id INTEGER;
	DECLARE cantidad SMALLINT;
	DECLARE nro_sala SMALLINT;
	
	
	
	SET aux_id = 
		(SELECT 
			COUNT(*) 
		FROM 
			efectores e 
		WHERE 
			e.id_efector = id_efector);
	
	IF aux_id=0 THEN
		
		RETURN -1;
		
	END IF;
	
	
	
	SET cantidad =
		(SELECT
			COUNT(*) 
		FROM
			salas s
		WHERE 
			s.id_efector = id_efector);
			
	IF cantidad = 0 THEN
	
		SET nro_sala = 1;
		
	ELSE
	
		
		SET nro_sala = 
		
			(SELECT 
				MAX(s.nro_sala)+1
			FROM 
				salas s
			WHERE 
				s.id_efector = id_efector);
	
	END IF;
	
	
	RETURN nro_sala;

END */$$
DELIMITER ;

/* Procedure structure for procedure `ciex_check_diagnosticos_operaciones` */

/*!50003 DROP PROCEDURE IF EXISTS  `ciex_check_diagnosticos_operaciones` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `ciex_check_diagnosticos_operaciones`(
    								IN ciex VARCHAR(255),
    								IN operaciones VARCHAR(255),
    								IN fecha_vigencia DATE,
    								OUT estado TINYINT,
    								OUT msg VARCHAR(255))
    COMMENT '0=restr;1=OK;2=err_dat_cie;3=err_dat_oper;4=warning;5=err_rn'
funcion:
BEGIN
	DECLARE cod_ciex CHAR(4);
	DECLARE	cod_3dig CHAR(3);
	DECLARE	cod_4dig CHAR(1);	
	DECLARE	cod_operacion CHAR(4);
	
	DECLARE posi INTEGER;
	DECLARE posj INTEGER;
	DECLARE posh INTEGER;
		
	DECLARE cant INTEGER;
	DECLARE cant_operaciones_obligatorias INTEGER;
	
	DECLARE flag_restriccion_operacion TINYINT;
	DECLARE flag_restriccion_operacion_validacion TINYINT;
	DECLARE flag_operacion_obligatoria_presente BOOLEAN;
	DECLARE flag_operacion_obligatoria_rn_presente BOOLEAN;
	DECLARE flag_operacion_puede_o_no_tener_fuera_de_rango BOOLEAN;
	
	
	DECLARE rangos_operaciones_obligatorias VARCHAR(255);
	DECLARE rangos_operaciones_puede_o_no_tener VARCHAR(255);
	DECLARE rangos_operaciones_obligatorias_rn VARCHAR(255);
	
	DECLARE rango_operaciones VARCHAR(255);
	
	DECLARE cod_operacion_desde CHAR(4);
	DECLARE cod_operacion_hasta CHAR(4);
	
	
		
	SET posi=1;	
	SET cod_ciex=(
				SELECT hmi2_str_split(ciex,';',posi)
				);
				
	
	IF cod_ciex='' THEN
		
		SET estado = 4;
		SET msg ='Diagnostico vacio';
		
		LEAVE funcion;
		
	END IF;
			
	
		
	
	
	
	WHILE cod_ciex<>'' DO
    
	
		
		IF LENGTH(cod_ciex)<>4 THEN
		
			SET estado = 2;
			SET msg =CONCAT('Diagnostico ',cod_ciex, ' no valido');
			
			LEAVE funcion;
			
		END IF;
		
		
		SET cod_3dig=LEFT(cod_ciex,3);
		SET cod_4dig=RIGHT(cod_ciex,1);
		
		
		SET cant=(
				SELECT
					COUNT(*)
				FROM
					ciex_4 c4
				WHERE
					c4.cod_3dig = cod_3dig
				AND c4.cod_4dig = cod_4dig);
		IF cant<>1 THEN
			
			SET estado = 2;
			SET msg =CONCAT('Diagnostico ',cod_3dig,'-',cod_4dig,' no existe');
			
			LEAVE funcion;
			
		END IF;		
		
		
		
		
		
		
			
		
		
		
	
		
		SET posj=1;
		SET cod_operacion=(
						SELECT hmi2_str_split(operaciones,';',posj)
						);	
						
		
		IF cod_operacion='' THEN
			
			SET estado = 4;
			SET msg ='Operacion vacia';
		
		END IF;
		
		
		
		
		SET flag_restriccion_operacion = 
							ciex_get_restriccion_operacion(
													cod_3dig,
													cod_4dig,
													fecha_vigencia);
		
		
		
		
												
		
		SET rangos_operaciones_obligatorias = 
							ciex_get_rangos_operaciones_diagnostico(
													cod_3dig,
				    								cod_4dig,
				    								1,
				    								fecha_vigencia);
		
		
		
		
												
		
		SET rangos_operaciones_obligatorias_rn = 
							ciex_get_rangos_operaciones_diagnostico(
													cod_3dig,
				    								cod_4dig,
				    								4,
				    								fecha_vigencia);
				    								
				    										    								
		
		
		
																		    										    								
		
		SET rangos_operaciones_puede_o_no_tener = 
							ciex_get_rangos_operaciones_diagnostico(
													cod_3dig,
				    								cod_4dig,
				    								3,
				    								fecha_vigencia);
				    								
		
				    								
		
		SET flag_operacion_obligatoria_presente = FALSE;
		
		
		SET flag_operacion_obligatoria_rn_presente = FALSE;
		
		
		SET flag_operacion_puede_o_no_tener_fuera_de_rango = FALSE;				    								
		
		
		
		
		
		
		
		
		
		WHILE cod_operacion<>'' DO
		
		
		
			
			IF LENGTH(cod_operacion)<>4 THEN
			
				SET estado = 3;
				SET msg =CONCAT('Operacion ',cod_operacion, ' no valida');
			
				LEAVE funcion;
				
			END IF;
		
			
			SET cant=(
					SELECT
						COUNT(*)
					FROM
						operaciones o
					WHERE
						o.cod_operacion = cod_operacion);
			IF cant<>1 THEN
				
				SET estado = 3;
				SET msg =CONCAT('Operacion ',cod_operacion, ' no existe');
				
				LEAVE funcion;
				
			END IF;
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			SET flag_restriccion_operacion_validacion = 
										ciex_check_restriccion_operacion_validacion(
														cod_3dig,
					    								cod_4dig,
					    								cod_operacion,
					    								fecha_vigencia);
					    								
			IF flag_restriccion_operacion_validacion = 2 THEN
			
				SET estado = 0;
				SET msg = CONCAT(
								'El diagnostico ',
								cod_3dig,
								'-',
								cod_4dig,
								' no puede tener la operacion ',
								cod_operacion);
			
				LEAVE funcion;
				
			END IF;
			
			
			
			
			
			
			
			IF flag_restriccion_operacion = 1 THEN
			
				
				
				SET posh=1;
				
				
				SET rango_operaciones = (
							SELECT hmi2_str_split(rangos_operaciones_obligatorias,' ',posh)
							);
							
							
							
				
				
				
				WHILE rango_operaciones<>'' DO
				
				
					
					SET cod_operacion_desde = (
								SELECT hmi2_str_split(rango_operaciones,'-',1)
								);
								
					
					SET cod_operacion_hasta = (
								SELECT hmi2_str_split(rango_operaciones,'-',2)
								);
				
								
					
					IF (cod_operacion_desde<=cod_operacion AND 
						cod_operacion<=cod_operacion_hasta) THEN
						
						SET flag_operacion_obligatoria_presente = TRUE;
						
					END IF;
								
								
					
					
					
					
					
					
					SET posh=posh+1;
					
					
					SET rango_operaciones=(
									SELECT hmi2_str_split(rangos_operaciones_obligatorias,' ',posh)
									);	
									
					
					
					
					
					
					
					
				END WHILE;
				
				
								
			END IF;
			
			
			
			
			
			
			IF flag_restriccion_operacion = 4 THEN
			
				
				
				SET posh=1;
				
				
				SET rango_operaciones = (
							SELECT hmi2_str_split(rangos_operaciones_obligatorias_rn,' ',posh)
							);
							
							
							
				
				
				
				WHILE rango_operaciones<>'' DO
				
				
					
					SET cod_operacion_desde = (
								SELECT hmi2_str_split(rango_operaciones,'-',1)
								);
								
					
					SET cod_operacion_hasta = (
								SELECT hmi2_str_split(rango_operaciones,'-',2)
								);
				
								
					
					IF (cod_operacion_desde<=cod_operacion AND 
						cod_operacion<=cod_operacion_hasta) THEN
						
						SET flag_operacion_obligatoria_rn_presente = TRUE;
						
					END IF;
								
								
					
					
					
					
					
					
					SET posh=posh+1;
					
					
					SET rango_operaciones=(
									SELECT hmi2_str_split(rangos_operaciones_obligatorias_rn,' ',posh)
									);	
									
					
					
					
					
					
					
					
				END WHILE;
				
				
								
			END IF;
			
			
			
			
			
			
			
			
			
			IF flag_restriccion_operacion = 3 AND 
				flag_restriccion_operacion_validacion<>1 AND
				flag_restriccion_operacion_validacion<>4 THEN
			
				
				
				SET posh=1;
				
				
				SET rango_operaciones = (
							SELECT hmi2_str_split(rangos_operaciones_puede_o_no_tener,' ',posh)
							);
							
							
							
				
				
				
				puede_o_no_tener:
				
				WHILE rango_operaciones<>'' DO
				
				
					
					SET cod_operacion_desde = (
								SELECT hmi2_str_split(rango_operaciones,'-',1)
								);
								
					
					SET cod_operacion_hasta = (
								SELECT hmi2_str_split(rango_operaciones,'-',2)
								);
				
								
					
					IF (cod_operacion_desde>cod_operacion OR 
						cod_operacion>cod_operacion_hasta) THEN
						
						SET flag_operacion_puede_o_no_tener_fuera_de_rango = TRUE;
						
					ELSE
					
						SET flag_operacion_puede_o_no_tener_fuera_de_rango = FALSE;
						
						LEAVE puede_o_no_tener;
						
					END IF;
								
								
					
					
					
					
					
					
					SET posh=posh+1;
					
					
					SET rango_operaciones=(
									SELECT hmi2_str_split(rangos_operaciones_puede_o_no_tener,' ',posh)
									);	
									
					
					
					
					
					
					
					
				END WHILE puede_o_no_tener;
				
				
								
			END IF;
			
			
			
			
			
			
			
			
			
			SET posj=posj+1;
			
			
			SET cod_operacion=(
							SELECT hmi2_str_split(operaciones,';',posj)
							);	
							
			
			
			
			
			
			
			
		END WHILE;
		
		
		
		IF flag_restriccion_operacion = 1 AND 
			flag_operacion_obligatoria_presente = FALSE THEN
			
			SET estado = 0;
			SET msg = CONCAT('El diagnostico ', 
						cod_3dig,
						'-',
						cod_4dig,
						' debe tener obligatoriamente una operacion del rango: ',
						rangos_operaciones_obligatorias);
						
			LEAVE funcion;
			
		END IF;
		
		
		
		IF flag_restriccion_operacion = 4 AND 
			flag_operacion_obligatoria_rn_presente = FALSE THEN
			
			SET estado = 5;
			SET msg = CONCAT('El diagnostico ', 
						cod_3dig,
						'-',
						cod_4dig,
						' debe tener obligatoriamente una operacion del rango: ',
						rangos_operaciones_obligatorias_rn,
						' en caso de que exista datos del recien nacido');
						
			LEAVE funcion;
			
		END IF;
		
		
		
			
		
		
		
		SET posi=posi+1;
		
		
		SET cod_ciex=(
					SELECT hmi2_str_split(ciex,';',posi)
					);
		
		
		
		
		
		
	END WHILE;
		
			
	
	
	
	
	
	IF posi=2 AND
		flag_restriccion_operacion = 3 AND
		posj>1 AND
		flag_operacion_puede_o_no_tener_fuera_de_rango = TRUE THEN
		
		
		
		SET estado = 0;
		SET msg = CONCAT('El diagnostico: ', cod_3dig,'-',cod_4dig,
						' definido como unico diagnostico, no puede tener operaciones ',
						'fuera de o los rangos: ',
						rangos_operaciones_puede_o_no_tener);
						
		
		
		
		IF flag_restriccion_operacion = 1 THEN
		
			SET msg = CONCAT(msg, 
							'. Rango de operaciones obligatorias: ',
							rangos_operaciones_obligatorias);
							
		END IF;
		
		LEAVE funcion;
			
	END IF;
	
	
	
	
	IF estado = 4 THEN
	
		LEAVE funcion;
		
	END IF;
	
	
	
	
	
	
	SET estado = 1;
	SET msg='OK';
	
	
	
END funcion */$$
DELIMITER ;

/* Procedure structure for procedure `hmi2_generar_listado_fechas` */

/*!50003 DROP PROCEDURE IF EXISTS  `hmi2_generar_listado_fechas` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `hmi2_generar_listado_fechas`(IN desde DATE, IN hasta DATE)
BEGIN
	DECLARE fin INT DEFAULT 0;
	DECLARE dia DATE;
	SET dia = ADDDATE(desde,-1);
	DROP TEMPORARY TABLE IF EXISTS
		tmp_listado_fechas;
	
	CREATE TEMPORARY TABLE 
		tmp_listado_fechas(fecha DATE);
	ciclo1: REPEAT
		SET dia = ADDDATE(dia, INTERVAL 1 DAY);
		SET fin = fin + 1;
		INSERT INTO 
			tmp_listado_fechas 
		VALUES
			(dia);
	UNTIL dia = hasta END REPEAT ciclo1;
	SELECT 
		fecha 
	FROM 
		tmp_listado_fechas;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `ciex_check_diagnosticos_operaciones_no_puede_tener_ninguna` */

/*!50003 DROP PROCEDURE IF EXISTS  `ciex_check_diagnosticos_operaciones_no_puede_tener_ninguna` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `ciex_check_diagnosticos_operaciones_no_puede_tener_ninguna`(
    								IN ciex VARCHAR(255),
    								IN fecha_vigencia DATE,
    								OUT estado TINYINT,
    								OUT msg VARCHAR(255))
    COMMENT '0=restringe;1=OK;2=err_datos_ciex;'
funcion:
BEGIN
	DECLARE cod_ciex CHAR(4);
	DECLARE	cod_3dig CHAR(3);
	DECLARE	cod_4dig CHAR(1);	
	
	DECLARE posi INTEGER;
	DECLARE posh INTEGER;
	
	DECLARE cant INTEGER;
	
	DECLARE flag_restriccion_operacion_no_puede_tener TINYINT;
	
	DECLARE rangos_operaciones_no_puede_tener VARCHAR(255);
	DECLARE rango_operaciones VARCHAR(255);
	
	DECLARE cod_operacion_desde CHAR(4);
	DECLARE cod_operacion_hasta CHAR(4);
	DECLARE cod_operacion_min CHAR(4);
	DECLARE cod_operacion_max CHAR(4);
	
	
	
	SET cod_operacion_min = (
				SELECT
					MIN(cod_operacion)
				FROM
					operaciones);
					
	
	SET cod_operacion_max = (
				SELECT
					MAX(cod_operacion)
				FROM
					operaciones);
	
				
					
		
	SET posi=1;	
	SET cod_ciex=(
				SELECT hmi2_str_split(ciex,';',posi)
				);
				
	
	IF cod_ciex='' THEN
		
		SET estado = 2;
		SET msg ='Diagnostico vacio';
		
		LEAVE funcion;
		
	END IF;
			
	
		
	
	
	
	WHILE cod_ciex<>'' DO
    
	
		
		IF LENGTH(cod_ciex)<>4 THEN
		
			SET estado = 2;
			SET msg =CONCAT('Diagnostico ',cod_ciex, ' no valido');
			
			LEAVE funcion;
			
		END IF;
		
		
		SET cod_3dig=LEFT(cod_ciex,3);
		SET cod_4dig=RIGHT(cod_ciex,1);
		
		
		SET cant=(
				SELECT
					COUNT(*)
				FROM
					ciex_4 c4
				WHERE
					c4.cod_3dig = cod_3dig
				AND c4.cod_4dig = cod_4dig);
		IF cant<>1 THEN
			
			SET estado = 2;
			SET msg =CONCAT('Diagnostico ',cod_3dig,'-',cod_4dig,' no existe');
			
			LEAVE funcion;
			
		END IF;		
		
		
													
		
		SET flag_restriccion_operacion_no_puede_tener = 
									ciex_check_restriccion_operacion_no_puede_tener (
																	cod_3dig, 
																	cod_4dig,
																	fecha_vigencia);
																	
		
																												
		
		
		IF flag_restriccion_operacion_no_puede_tener = 2  THEN
		
			
			
			SET rangos_operaciones_no_puede_tener = 
							ciex_get_rangos_operaciones_diagnostico(
													cod_3dig,
				    								cod_4dig,
				    								2,
				    								fecha_vigencia);
				    								
				    								
			
			SET posh=1;
			
			
			SET rango_operaciones = (
						SELECT hmi2_str_split(rangos_operaciones_no_puede_tener,' ',posh)
						);
							
							
							
			
			
			
			WHILE rango_operaciones<>'' DO
			
			
				
				SET cod_operacion_desde = (
							SELECT hmi2_str_split(rango_operaciones,'-',1)
							);
							
				
				SET cod_operacion_hasta = (
							SELECT hmi2_str_split(rango_operaciones,'-',2)
							);
			
							
				
				IF (cod_operacion_desde = cod_operacion_min AND 
					cod_operacion_hasta = cod_operacion_max) THEN
					
					SET estado = 0;
					SET msg = CONCAT('El diagnostico: ', cod_3dig,'-',cod_4dig,
									' no puede tener operaciones');
					
					LEAVE funcion;
					
				END IF;
							
							
				
				
				
				
				
				
				SET posh=posh+1;
				
				
				SET rango_operaciones=(
								SELECT hmi2_str_split(rangos_operaciones_no_puede_tener,' ',posh)
								);	
								
				
				
				
				
				
				
				
			END WHILE;
				
				
								
		END IF;
		
		
		
		
			
		
		
		
		SET posi=posi+1;
		
		
		SET cod_ciex=(
					SELECT hmi2_str_split(ciex,';',posi)
					);
		
		
		
		
		
		
	END WHILE;
		
	
	
	
	
	SET estado = 1;
	SET msg='OK';
	
END funcion */$$
DELIMITER ;

/* Procedure structure for procedure `ciex_get_restricciones_edad` */

/*!50003 DROP PROCEDURE IF EXISTS  `ciex_get_restricciones_edad` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `ciex_get_restricciones_edad`(
    							IN cod_3dig CHAR(3),
    							IN cod_4dig CHAR(4),
    							OUT ptipoedad_min TINYINT, 
    							OUT pedad_min TINYINT,
    							OUT ptipoedad_max TINYINT,
    							OUT pedad_max TINYINT,
    							OUT prestriccion_edad TINYINT,
    							IN fecha_vigencia DATE)
    COMMENT 'Restricciones de edad'
BEGIN
	DECLARE tipoedad_min_aux TINYINT;
	DECLARE	edad_min_aux TINYINT;
	DECLARE	tipoedad_max_aux TINYINT;
	DECLARE	edad_max_aux TINYINT;
	DECLARE	restriccion_edad_aux TINYINT;
	
	DECLARE continuar BOOLEAN;
	
	
	
	SET continuar = TRUE;
	
	
	
	
	
	
	(SELECT 
		tipoedad_min,
		edad_min,
		tipoedad_max,
		edad_max,
		restriccion_edad 
	INTO
		tipoedad_min_aux,
		edad_min_aux,
		tipoedad_max_aux,
		edad_max_aux,
		restriccion_edad_aux
	FROM
		ciex_restricciones cr
	WHERE
		cr.cod_3dig = cod_3dig
	AND cr.cod_4dig = cod_4dig
	AND cr.fecha_vigencia_desde <= fecha_vigencia 
	AND (cr.fecha_vigencia_hasta IS NULL 
		OR cr.fecha_vigencia_hasta >= fecha_vigencia)
	);
	
	
	
	
	
	
	
	
	IF tipoedad_min_aux IS NOT NULL THEN
	
		
		
		SET ptipoedad_min = tipoedad_min_aux;
		SET pedad_min = edad_min_aux;
		SET ptipoedad_max = tipoedad_max_aux;
		SET pedad_max = edad_max_aux;
		SET prestriccion_edad = restriccion_edad_aux;
		
		SET continuar = FALSE;
		
	END IF;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	IF continuar THEN
	
		(SELECT 
			tipoedad_min,
			edad_min,
			tipoedad_max,
			edad_max,
			restriccion_edad 
		INTO
			tipoedad_min_aux,
			edad_min_aux,
			tipoedad_max_aux,
			edad_max_aux,
			restriccion_edad_aux
		FROM
			ciex_restricciones cr
		WHERE
			cr.cod_3dig = cod_3dig
		AND cr.id_ciex_4 IS NULL
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
		
		
		
		
		
		
		IF tipoedad_min_aux IS NOT NULL THEN
		
			
			
			SET ptipoedad_min = tipoedad_min_aux;
			SET pedad_min = edad_min_aux;
			SET ptipoedad_max = tipoedad_max_aux;
			SET pedad_max = edad_max_aux;
			SET prestriccion_edad = restriccion_edad_aux;
			
			SET continuar = FALSE;
	        
	        
		END IF;
	
	END IF;
	
	
	
	
	
	
	
	IF continuar THEN
	
		(SELECT 
			tipoedad_min,
			edad_min,
			tipoedad_max,
			edad_max,
			restriccion_edad 
		INTO
			tipoedad_min_aux,
			edad_min_aux,
			tipoedad_max_aux,
			edad_max_aux,
			restriccion_edad_aux
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo<>'00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
		
		
		
		
		
		
		IF tipoedad_min_aux IS NOT NULL THEN
		
			
			
			SET ptipoedad_min = tipoedad_min_aux;
			SET pedad_min = edad_min_aux;
			SET ptipoedad_max = tipoedad_max_aux;
			SET pedad_max = edad_max_aux;
			SET prestriccion_edad = restriccion_edad_aux;
			
			SET continuar = FALSE;
	        
	        
		END IF;
	
		
	END IF;	
	
	
	
	
	
	
	
	
	IF continuar THEN
	
		(SELECT 
			tipoedad_min,
			edad_min,
			tipoedad_max,
			edad_max,
			restriccion_edad 
		INTO
			tipoedad_min_aux,
			edad_min_aux,
			tipoedad_max_aux,
			edad_max_aux,
			restriccion_edad_aux
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo<>'00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
		
		
		
		
		
		
		IF tipoedad_min_aux IS NOT NULL THEN
		
			
			
			SET ptipoedad_min = tipoedad_min_aux;
			SET pedad_min = edad_min_aux;
			SET ptipoedad_max = tipoedad_max_aux;
			SET pedad_max = edad_max_aux;
			SET prestriccion_edad = restriccion_edad_aux;
			
			SET continuar = FALSE;
	        
	        
		END IF;
	
	END IF;	
	
	
	
	
	
	
	
	
	
	IF continuar THEN
	
		(SELECT 
			tipoedad_min,
			edad_min,
			tipoedad_max,
			edad_max,
			restriccion_edad 
		INTO
			tipoedad_min_aux,
			edad_min_aux,
			tipoedad_max_aux,
			edad_max_aux,
			restriccion_edad_aux
		FROM
			ciex_restricciones cr
		INNER JOIN
			ciex_titulos ct
		ON
			cr.id_ciex_titulo = ct.id_ciex_titulo
		WHERE
			ct.cod_3dig_desde <= cod_3dig
		AND ct.cod_3dig_hasta >= cod_3dig
		AND ct.subgrupo='00'
		AND ct.grupo='00'
		AND ct.capitulo<>'00'
		AND cr.fecha_vigencia_desde <= fecha_vigencia 
		AND (cr.fecha_vigencia_hasta IS NULL 
			OR cr.fecha_vigencia_hasta >= fecha_vigencia)
		);
		
		
		
		
		
		
		
		
		IF tipoedad_min_aux IS NOT NULL THEN
		
			
			
			SET ptipoedad_min = tipoedad_min_aux;
			SET pedad_min = edad_min_aux;
			SET ptipoedad_max = tipoedad_max_aux;
			SET pedad_max = edad_max_aux;
			SET prestriccion_edad = restriccion_edad_aux;
			
			SET continuar = FALSE;
	        
	        
		END IF;
		
	END IF;
	
	
	IF continuar THEN
		
		SET ptipoedad_min = 9;
		SET pedad_min = 0;
		SET ptipoedad_max = 0;
		SET pedad_max = 99;
		SET prestriccion_edad = 0;
		
		SET continuar = FALSE;	
	
	END IF;
	
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
