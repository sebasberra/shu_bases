/*
SQLyog Community v12.01 (32 bit)
MySQL - 10.0.25-MariaDB : Database - auditoria0_2_1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `datos` */

DROP TABLE IF EXISTS `datos`;

CREATE TABLE `datos` (
  `id_dato` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id del registro de movimiento de datos',
  `id_transaccion` int(11) NOT NULL COMMENT 'id de transaccion que vincula los movimientos de datos',
  `sistema_db` varchar(64) NOT NULL COMMENT 'Nombre literal de la base de datos auditada, el cual debe corresponderse con el campo sistema_db de la tabla sistemas_auditados',
  `tabla` varchar(64) NOT NULL COMMENT 'Nombre literal de la tabla donde se efectuo el movimiento de registros',
  `campos` text NOT NULL COMMENT 'Nombres de campos separados por ;',
  `valores` text NOT NULL COMMENT 'Valores de los campos separados por ;',
  `tipo_sql` char(1) NOT NULL COMMENT 'I=insert;N=update new; O=update old; D=delete;',
  `fecha_hora` datetime NOT NULL COMMENT 'Fecha y hora de registro del dato',
  PRIMARY KEY (`id_dato`),
  KEY `fk_transacciones_id_transaccion` (`id_transaccion`),
  KEY `idx_campos` (`campos`(20)),
  KEY `idx_sistema_db` (`sistema_db`),
  KEY `idx_tabla` (`tabla`),
  KEY `idx_valores` (`valores`(20)),
  KEY `idx_fecha_hora` (`fecha_hora`),
  KEY `idx_tipo_sql` (`tipo_sql`),
  CONSTRAINT `fk_datos_transacciones` FOREIGN KEY (`id_transaccion`) REFERENCES `transacciones` (`id_transaccion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `datos` */

/*Table structure for table `logins` */

DROP TABLE IF EXISTS `logins`;

CREATE TABLE `logins` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id del login',
  `trx_mysql_thread_id` bigint(4) NOT NULL COMMENT 'ID de PROCESSLIST. tener en cuenta que si el servidor reinicia los ID tambien',
  `usuario_db` varchar(64) NOT NULL COMMENT 'Usuario de la base de datos',
  `host_usuario` varchar(64) NOT NULL COMMENT 'Host desde donde se conecto el usuario a la base de datos',
  `id_person` int(11) NOT NULL COMMENT 'id_person del diagnose',
  `usuario_sistema` varchar(100) NOT NULL COMMENT 'Usuario del sistema, no de la base de datos',
  `evento` varchar(80) NOT NULL COMMENT 'descripcion del evento de usuario, se usa para guardar en las transacciones',
  `fecha_hora_login` datetime NOT NULL COMMENT 'Fecha y hora que el usuario entro',
  `fecha_hora_logout` datetime DEFAULT NULL COMMENT 'Fecha y hora que el usuario salio',
  `fecha_modificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha modificacion del registro',
  PRIMARY KEY (`id_login`),
  UNIQUE KEY `idx_unique_trx_mysql_thread_id_fecha_hora_logout` (`trx_mysql_thread_id`,`fecha_hora_logout`),
  KEY `idx_usuario_db` (`usuario_db`),
  KEY `idx_host_usuario` (`host_usuario`),
  KEY `idx_id_person` (`id_person`),
  KEY `idx_usuario_sistema` (`usuario_sistema`),
  KEY `idx_fecha_hora_login` (`fecha_hora_login`),
  KEY `idx_fecha_hora_logout` (`fecha_hora_logout`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `logins` */

/*Table structure for table `sistemas_auditados` */

DROP TABLE IF EXISTS `sistemas_auditados`;

CREATE TABLE `sistemas_auditados` (
  `id_sistema_auditado` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id de sistema a auditar',
  `sistema_descripcion` varchar(100) NOT NULL COMMENT 'Nombre descriptivo del sistema a auditar',
  `sistema_db` varchar(64) NOT NULL COMMENT 'Nombre de base de datos. se hace referencia desde el procedimiento auditar para obtener el id_sistema_auditado y guardarlo en transacciones',
  `estado` tinyint(4) NOT NULL COMMENT '0=desactivada o 1=activada la gestion de auditoria',
  `observacion` varchar(255) DEFAULT NULL COMMENT 'Comentario sobre la auditoria del sistema seleccionado',
  PRIMARY KEY (`id_sistema_auditado`),
  UNIQUE KEY `idx_unique_sistema_db` (`sistema_db`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `sistemas_auditados` */

/*Table structure for table `transacciones` */

DROP TABLE IF EXISTS `transacciones`;

CREATE TABLE `transacciones` (
  `id_transaccion` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id de transaccion del sistema de auditoria',
  `id_sistema_auditado` int(11) NOT NULL,
  `id_login` int(11) NOT NULL,
  `trx_id` varchar(18) NOT NULL COMMENT 'id de transaccion interna de mysql, tabla information_schema.INNODB_TRX',
  `fecha_hora` datetime NOT NULL COMMENT 'fecha y hora de la transaccion',
  `descripcion` varchar(255) NOT NULL COMMENT 'Cualquier descripcion asociada a la transaccion',
  PRIMARY KEY (`id_transaccion`),
  KEY `idx_descripcion` (`descripcion`),
  KEY `fk_sistemas_auditados_id_sistema_auditado` (`id_sistema_auditado`),
  KEY `fk_logins_id_login` (`id_login`),
  KEY `idx_fecha_hora` (`fecha_hora`),
  CONSTRAINT `fk_transacciones1` FOREIGN KEY (`id_sistema_auditado`) REFERENCES `sistemas_auditados` (`id_sistema_auditado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_transacciones3` FOREIGN KEY (`id_login`) REFERENCES `logins` (`id_login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transacciones` */

/*Table structure for table `versiones` */

DROP TABLE IF EXISTS `versiones`;

CREATE TABLE `versiones` (
  `base` varchar(255) NOT NULL COMMENT 'nombre de la base de datos a la que corresponde el nro de version',
  `major` tinyint(4) NOT NULL COMMENT 'numero de version major',
  `minor` tinyint(4) NOT NULL COMMENT 'numero de version minor',
  `revision` smallint(6) NOT NULL COMMENT 'numero de revision de la version',
  `fecha` datetime NOT NULL COMMENT 'fecha de generacion de la version',
  PRIMARY KEY (`base`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='versionado de las bases de datos o subconjuntos de tablas';

/*Data for the table `versiones` */

insert  into `versiones`(`base`,`major`,`minor`,`revision`,`fecha`) values ('auditoria',0,2,1,'2014-07-11 09:58:52');

/*!50106 set global event_scheduler = 1*/;

/* Event structure for event `garbage_collector_event` */

/*!50106 DROP EVENT IF EXISTS `garbage_collector_event`*/;

DELIMITER $$

/*!50106 CREATE EVENT `garbage_collector_event` ON SCHEDULE EVERY 1 DAY STARTS '2014-07-04 00:00:00' ON COMPLETION NOT PRESERVE ENABLE COMMENT 'Ejecuta el garbage collector de logins de auditoria' DO BEGIN
		
		
			CALL auditar_garbage_collector(@estado,@msg);
			
		
		END */$$
DELIMITER ;

/* Function  structure for function  `auditar_get_id_login` */

/*!50003 DROP FUNCTION IF EXISTS `auditar_get_id_login` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `auditar_get_id_login`(
    						id_person_audit INTEGER,
    						usuario_sistema_audit VARCHAR(100) ) RETURNS int(11)
    READS SQL DATA
    COMMENT '0=no logeado o id_login'
BEGIN
	DECLARE id_login_aux INTEGER;
		
	
	/* busca id_login segun parametros */
	SET id_login_aux =
		(SELECT 
			l.id_login
		
		FROM
			logins l
		WHERE
			l.id_person = id_person_audit
		AND l.usuario_sistema = usuario_sistema_audit
		AND l.fecha_hora_logout IS NULL 
		LIMIT 0,1);
	
	/* check si encontro al usuario */
	IF id_login_aux IS NOT NULL THEN
	
		RETURN id_login_aux;
		
	END IF;
	
	RETURN 0;
	
	
END */$$
DELIMITER ;

/* Function  structure for function  `auditar_get_id_login2` */

/*!50003 DROP FUNCTION IF EXISTS `auditar_get_id_login2` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `auditar_get_id_login2`(
    						processlist_id BIGINT(4) ) RETURNS int(11)
    READS SQL DATA
    COMMENT '0=no logeado o id_login'
BEGIN
	DECLARE id_login_aux INTEGER;
		
	
	/* busca id_login segun parametros */
	SET id_login_aux =
		(SELECT 
			l.id_login
		FROM
			logins l
		WHERE
			l.trx_mysql_thread_id = processlist_id
		AND l.fecha_hora_logout IS NULL );
	
	/* check si encontro al usuario */
	IF id_login_aux IS NOT NULL THEN
	
		RETURN id_login_aux;
		
	END IF;
	
	RETURN 0;
	
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar_set_descripcion_evento` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar_set_descripcion_evento` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar_set_descripcion_evento`(
    			IN descripcion_evento VARCHAR(80),
    			IN id_login_evento INTEGER)
    COMMENT 'setea campo logins.evento'
BEGIN
	UPDATE
		logins
	SET
		evento = descripcion_evento
	WHERE
		id_login = id_login_evento
	AND fecha_hora_logout IS NULL;
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar`(
				IN nombre_db VARCHAR(64),
				IN nombre_tabla VARCHAR(64), 
				IN valor_primary_key INTEGER,
				IN tipo_sql CHAR(1),
				OUT estado INTEGER,
				OUT msg VARCHAR(255))
BEGIN
	
	/* logs_temporales */
	DECLARE id_login_aux			INTEGER;
	DECLARE trx_id_aux				VARCHAR(18);
	DECLARE usuario_db_aux			VARCHAR(64);
	DECLARE host_usuario_aux		VARCHAR(64);
	DECLARE	id_person_aux			INTEGER;
	DECLARE	usuario_sistema_aux		VARCHAR(100);
	DECLARE desc_evento_aux			VARCHAR(255);
	
	/* transacciones */
	DECLARE id_sistema_auditado_aux	INTEGER;
	DECLARE id_transaccion_aux		INTEGER;
	
	/* datos */
	DECLARE campo_aux				VARCHAR(64);
	DECLARE campos					VARCHAR(2048);
	DECLARE campos_concat_sql		VARCHAR(2048);
	DECLARE primarykey				VARCHAR(64);
	DECLARE valores_sql				VARCHAR(2048);
	
	/* variables extras */
	DECLARE cant_aux			INTEGER;
	DECLARE processlist_id		INTEGER;
		
	/* sqlstates */
	DECLARE tabla_no_existe CONDITION FOR SQLSTATE '42S02';
	DECLARE sintaxis_acceso_error CONDITION FOR SQLSTATE '42000';
	DECLARE fallo_comunicacion CONDITION FOR SQLSTATE '08S01';
	DECLARE error_general CONDITION FOR SQLSTATE 'HY000';
	
	/* variables */
	DECLARE eof BOOLEAN;
	DECLARE cantidad INT;
	
	/* cursores */
	
	/* busca los campos de la tabla */
	DECLARE 
		cursor_campos_tabla
	CURSOR FOR
		(SELECT 
			isc.COLUMN_NAME
		FROM
			INFORMATION_SCHEMA.COLUMNS isc
		WHERE
			isc.TABLE_SCHEMA=nombre_db
		AND isc.TABLE_NAME=nombre_tabla);
		
	/* flag fetch cursors */
	DECLARE CONTINUE HANDLER 
		FOR 
			NOT FOUND 
		BEGIN
			SET eof = TRUE;
		END;
	/* handler para errores */
	DECLARE EXIT HANDLER 
		FOR 
			sintaxis_acceso_error
		BEGIN 
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de sintaxis o error de acceso';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			fallo_comunicacion
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de comunicacion';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			error_general
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error general';
		END;
		
	/* setea a OK */
	SET estado=0;
	
	/* check si esta habilitada la audicion de la base */
	(SELECT	
		COUNT(*) AS cant
	INTO
		cantidad
	FROM 			
		sistemas_auditados sa 		
	WHERE 
		sa.sistema_db=nombre_db
	AND sa.estado = 1);
	
	IF cantidad=0 THEN
	
	
		/* return warning */
		SET estado=2;
		
		/* no se audita la base */
		SET msg='Base no auditable';
		
		
	ELSE
	
	
		/* ------- */
		/* auditar */
		/* ------- */
		
		
		/* check si hay login del thread */
		SET processlist_id = CONNECTION_ID();
		
		(SELECT
			auditar_get_id_login2(processlist_id)
		INTO
			id_login_aux);
		
		IF id_login_aux=0 THEN
			
			/* no se registra login */
			
			/* login automatico */
			CALL auditar_conexion(0,'auditoria automatica',id_login_aux);
			
		END IF;
		
		/* id transaccion */
		(SELECT
			l.id_login,	
			isi.trx_id,
			l.usuario_db,
			l.host_usuario,
			l.id_person,
			l.usuario_sistema,
			l.evento
			
		INTO
			id_login_aux,
			trx_id_aux,
			usuario_db_aux,
			host_usuario_aux,
			id_person_aux,	
			usuario_sistema_aux,
			desc_evento_aux
		FROM 			
			INFORMATION_SCHEMA.INNODB_TRX isi
		INNER JOIN
			logins l
		ON
			l.trx_mysql_thread_id = isi.trx_mysql_thread_id
		LIMIT 0,1);
		
		
		/* check id transaccion encontrada */
		IF trx_id_aux IS NULL THEN
		
			/* return warning */
			SET estado=2;
			
			/* mensaje */
			SET msg='ID de transaccion no encontrado';
			
			
		ELSE
		
		
			/* ------------------ */
			/* guarda transaccion */
			/* ------------------ */
			
			
			/* recupera los nombres de campos de la tabla */
			SET campos='';
			SET campos_concat_sql='';
			SET eof=FALSE;
			
			OPEN cursor_campos_tabla;
			
			bucle_campos:
			LOOP
			
				FETCH 
					cursor_campos_tabla 
				INTO 
					campo_aux;
					
				IF eof=TRUE THEN
				
					LEAVE bucle_campos;
					
				END IF;
				
				/* check que no supere los 1024 caracteres */
				IF LENGTH(CONCAT(campos,campo_aux,'; '))>2048 THEN
					
					/* return warning */
					SET estado=2;
					
					/* mensaje */
					SET msg='Nombres de campos truncados';
					
				ELSE
					
					/* concatena campos para la guardar en arreglo de nombres de campos */
					SET campos=CONCAT(campos,campo_aux,'; ');
					
					/* concatena campos para consultar los valores del registro para guardar */
					SET campos_concat_sql=CONCAT(campos_concat_sql,campo_aux,',\';\',');
					
				END IF;
				
			END LOOP;
				
			CLOSE cursor_campos_tabla;
		
		
				
			/* busca si la transaccion existe en la tabla de transacciones */
			(SELECT
				COUNT(*) AS cant
			INTO
				cant_aux
			FROM
				transacciones t
			WHERE
				t.trx_id = trx_id_aux
			AND t.id_login = id_login_aux);
				
			/* check transaccion creada */
			IF cant_aux=0 THEN
			
				/* id_sistema_auditado */
				(SELECT	
					sa.id_sistema_auditado
				INTO
					id_sistema_auditado_aux
				FROM 			
					sistemas_auditados sa 		
				WHERE 
					sa.sistema_db=nombre_db
				);
					
				/* ingresa la transaccion */
				INSERT INTO
					transacciones
				VALUES (
				
					/* id_transaccion */
					NULL,
					
					/* id_sistema_auditado */
					id_sistema_auditado_aux,
					
					/* id_login */
					id_login_aux,
					
					/* trx_id */
					trx_id_aux,
					
					/* fecha_hora */
					NOW(),
					
					/* descripcion */
					desc_evento_aux);
					
					
					
				/* captura id transaccion */
				(SELECT
					LAST_INSERT_ID()
				INTO
					id_transaccion_aux);
					
			END IF;
			
			
			/* busca el nombre de columna de la primary key de la tabla */
			(SELECT 
				kcu.COLUMN_NAME
			INTO
				primarykey
			FROM
				INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
			WHERE
				kcu.CONSTRAINT_SCHEMA=nombre_db
			AND kcu.TABLE_NAME=nombre_tabla
			AND	kcu.CONSTRAINT_NAME='PRIMARY');
			
			
			
			/* prepara el sql para ingresar el registro de datos */
			SET @guardar_datos = 'INSERT INTO datos VALUES ( ';
							
			/* id_dato */
			SET @guardar_datos = CONCAT( @guardar_datos,'NULL, ');
						
			/* id_transaccion */
			SET @guardar_datos = CONCAT( @guardar_datos,id_transaccion_aux,', ');
				
			/* sistema_db */
			SET @guardar_datos = CONCAT( @guardar_datos,'\'', nombre_db,'\', ');
				
			/* tabla */
			SET @guardar_datos = CONCAT( @guardar_datos,'\'', nombre_tabla,'\', ');
				
			/* campos */
			SET @guardar_datos = CONCAT( @guardar_datos, '\'', campos,'\', ');
			
			/* valores */
			SET valores_sql = '(SELECT CONCAT_WS(\';\', ';
			SET valores_sql = CONCAT(
									valores_sql,
									LEFT(campos_concat_sql,
										LENGTH(campos_concat_sql)-1),
									') ',' ');
			SET valores_sql = CONCAT( valores_sql,'FROM',' ',nombre_db,'.',nombre_tabla,' ');
			SET valores_sql = CONCAT( valores_sql,'WHERE',' ',primarykey,' = ',valor_primary_key,'), ');
			SET @guardar_datos = CONCAT( @guardar_datos,valores_sql);			
			
			/* tipo_sql */
			SET @guardar_datos = CONCAT( @guardar_datos,'\'',tipo_sql,'\', ');
				
			/* fecha_hora */
			SET @guardar_datos = CONCAT( @guardar_datos,'NOW() )');
			
			
			/* prepara la sentencia */
			PREPARE sqldatos FROM @guardar_datos;
			
			/* ejecuta la sentencia */
			EXECUTE sqldatos;
			
			/* descarga sentencia */
			DEALLOCATE PREPARE sqldatos;
	
		END IF;
			
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar2` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar2` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar2`(
				IN nombre_db VARCHAR(64),
				IN nombre_tabla VARCHAR(64), 
				IN campos TEXT,
				IN valores TEXT,
				IN tipo_sql CHAR(1),
				OUT estado INTEGER,
				OUT msg VARCHAR(255))
BEGIN
	
	/* logs_temporales */
	DECLARE id_login_aux			INTEGER;
	DECLARE trx_id_aux				VARCHAR(18);
	DECLARE usuario_db_aux			VARCHAR(64);
	DECLARE host_usuario_aux		VARCHAR(64);
	DECLARE	id_person_aux			INTEGER;
	DECLARE	usuario_sistema_aux		VARCHAR(100);
	DECLARE desc_evento_aux			VARCHAR(255);
	
	
	/* transacciones */
	DECLARE id_sistema_auditado_aux	INTEGER;
	DECLARE id_transaccion_aux		INTEGER;
	
		
	/* sqlstates */
	DECLARE tabla_no_existe CONDITION 		FOR SQLSTATE '42S02';
	DECLARE sintaxis_acceso_error CONDITION FOR SQLSTATE '42000';
	DECLARE fallo_comunicacion CONDITION 	FOR SQLSTATE '08S01';
	DECLARE error_general CONDITION 		FOR SQLSTATE 'HY000';
	
	
	/* variables */
	DECLARE eof 			BOOLEAN;
	DECLARE cant_aux		INTEGER;
	DECLARE processlist_id	BIGINT(4);	
		
	
	/* flag fetch cursors */
	DECLARE CONTINUE HANDLER 
		FOR 
			NOT FOUND 
		BEGIN
			SET eof = TRUE;
		END;
	/* handler para errores */
	DECLARE EXIT HANDLER 
		FOR 
			sintaxis_acceso_error
		BEGIN 
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de sintaxis o error de acceso';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			fallo_comunicacion
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de comunicacion';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			error_general
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error general';
		END;
		
	/* setea a OK */
	SET estado=0;
	
	/* check si esta habilitada la audicion de la base */
	(SELECT	
		COUNT(*) AS cant
	INTO
		cant_aux
	FROM 			
		sistemas_auditados sa 		
	WHERE 
		sa.sistema_db=nombre_db
	AND sa.estado = 1);
	
	IF cant_aux=0 THEN
	
	
		/* return warning */
		SET estado=2;
		
		/* no se audita la base */
		SET msg='Base no auditable';
		
		
	ELSE
	
	
		/* ------- */
		/* auditar */
		/* ------- */
		
		
		/* check si hay login del thread */
		SET processlist_id = CONNECTION_ID();
		
		(SELECT
			auditar_get_id_login2(processlist_id)
		INTO
			id_login_aux);
		
		IF id_login_aux=0 THEN
			
			/* no se registra login */
			
			/* login automatico */
			CALL auditar_conexion(0,'auditoria automatica',id_login_aux);
			
		END IF;
		
		
		
		/* id transaccion */
		(SELECT
			l.id_login,	
			isi.trx_id,
			l.usuario_db,
			l.host_usuario,
			l.id_person,
			l.usuario_sistema,
			l.evento
			
		INTO
			id_login_aux,
			trx_id_aux,
			usuario_db_aux,
			host_usuario_aux,
			id_person_aux,	
			usuario_sistema_aux,
			desc_evento_aux
		FROM 			
			INFORMATION_SCHEMA.INNODB_TRX isi
		INNER JOIN
			logins l
		ON
			l.trx_mysql_thread_id = isi.trx_mysql_thread_id
		LIMIT 0,1);
		
		
		/* check id transaccion encontrada */
		IF trx_id_aux IS NULL THEN
		
			/* return warning */
			SET estado=2;
			
			/* mensaje */
			SET msg='ID de transaccion no encontrado';
			
			
		ELSE
		
		
		
			/* ------------------ */
			/* guarda transaccion */
			/* ------------------ */
			
			
				
			/* busca si la transaccion existe en la tabla de transacciones */
			(SELECT
				id_transaccion
			INTO
				id_transaccion_aux
			FROM
				transacciones t
			WHERE
				t.trx_id = trx_id_aux
			AND t.id_login = id_login_aux);
				
			/* check transaccion creada */
			IF id_transaccion_aux IS NULL THEN
			
				/* id_sistema_auditado */
				(SELECT	
					sa.id_sistema_auditado
				INTO
					id_sistema_auditado_aux
				FROM 			
					sistemas_auditados sa 		
				WHERE 
					sa.sistema_db=nombre_db
				);
					
				
				/* ingresa la transaccion */
				INSERT INTO
					transacciones
				VALUES (
				
					/* id_transaccion */
					NULL,
					
					/* id_sistema_auditado */
					id_sistema_auditado_aux,
					
					/* id_login */
					id_login_aux,
					
					/* trx_id */
					trx_id_aux,
					
					/* fecha_hora */
					NOW(),
					
					/* descripcion */
					desc_evento_aux);
					
				/* captura id transaccion */
				(SELECT
					LAST_INSERT_ID()
				INTO
					id_transaccion_aux);
					
			END IF;
			
			
			/* prepara el sql para ingresar el registro de datos */
			INSERT INTO 
			
				datos 
				
			VALUES 
			
				(
							
				/* id_dato */
				NULL,
						
				/* id_transaccion */
				id_transaccion_aux,
					
				/* sistema_db */
				nombre_db,
					
				/* tabla */
				nombre_tabla,
					
				/* campos */
				campos,
				
				/* valores */
				valores,
				
				/* tipo_sql */
				tipo_sql,
					
				/* fecha_hora */
				NOW() );
			
		END IF;
			
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar_desconexion` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar_desconexion` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar_desconexion`(
				IN id_person_audit INTEGER, 
				IN usuario_sistema_audit VARCHAR(100),
				OUT estado INTEGER,
				OUT msg VARCHAR(255))
BEGIN
	
	/* sqlstates */
	DECLARE tabla_no_existe CONDITION 		FOR SQLSTATE '42S02';
	DECLARE sintaxis_acceso_error CONDITION FOR SQLSTATE '42000';
	DECLARE fallo_comunicacion CONDITION 	FOR SQLSTATE '08S01';
	DECLARE error_general CONDITION 		FOR SQLSTATE 'HY000';
	
	
	/* variables */
	DECLARE eof 					BOOLEAN;
	DECLARE id_login_aux 			INTEGER;
	DECLARE trx_mysql_thread_id_aux BIGINT(4);
	DECLARE cant INTEGER;
	DECLARE segundos INTEGER;
	
	
	
	/* cursores */
	
	/* obtiene el id_login */
	DECLARE 
		cursor_id_logins
	CURSOR FOR
		(SELECT 
			l.id_login,
			l.trx_mysql_thread_id
		FROM
			logins l
		WHERE
			l.id_person = id_person_audit
		AND l.usuario_sistema = usuario_sistema_audit
		AND	l.fecha_hora_logout IS NULL 
		);
		
	/* flag fetch cursors */
	DECLARE CONTINUE HANDLER 
		FOR 
			NOT FOUND 
		BEGIN
			SET eof = TRUE;
		END;
	/* handler para errores */
	DECLARE EXIT HANDLER 
		FOR 
			sintaxis_acceso_error
		BEGIN 
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de sintaxis o error de acceso';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			fallo_comunicacion
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de comunicacion';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			error_general
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error general';
		END;
		
	/* setea a OK */
	SET estado=0;
	SET eof=FALSE;
	SET segundos=0;
	
	OPEN cursor_id_logins;
			
	bucle_id_logins:
	
	LOOP
	
		FETCH 
			cursor_id_logins 
		INTO 
			id_login_aux,
			trx_mysql_thread_id_aux;
			
		IF eof=TRUE THEN
		
			LEAVE bucle_id_logins;
			
		END IF;
			
		/* busca en PROCESSLIST si esta el id de hilo del login */
		(SELECT
			COUNT(*) 
		INTO
			cant
		FROM
			INFORMATION_SCHEMA.PROCESSLIST pl
		
		WHERE
			pl.ID = trx_mysql_thread_id_aux);
			
		/* check si esta existe el hilo */
		IF cant=0 THEN
		
			/* cierra el logins porque el hilo de proceso no existe */
			UPDATE
				logins
			SET
				fecha_hora_logout = DATE_ADD(NOW(),INTERVAL segundos SECOND),
				evento = 'desconexion por id y usuario sin thread de conexion'
			WHERE
				id_login = id_login_aux;
				
			/* segundos++ */
			SET segundos=segundos+1;
		
		ELSE
		
			/* check si es el hilo actual de conexion */
			IF trx_mysql_thread_id_aux=CONNECTION_ID() THEN
			
				/* cierra el logins porque el hilo de proceso no existe */
				UPDATE
					logins
				SET
					fecha_hora_logout = DATE_ADD(NOW(),INTERVAL segundos SECOND),
					evento = 'desconexion correspondiente a id y usuario'
				WHERE
					id_login = id_login_aux;
					
				/* segundos++ */
				SET segundos=segundos+1;
				
			END IF;
					
		END IF;
		
			
	END LOOP;
			
	CLOSE cursor_id_logins;
	
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar_conexion` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar_conexion` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar_conexion`(
				IN id_person INTEGER,
				IN usuario_sistema VARCHAR(100),
				OUT id_login_out INTEGER)
BEGIN
	
	DECLARE id_login_aux INTEGER;
	
	
	DECLARE id_person_aux INTEGER;
	DECLARE usuario_sistema_aux VARCHAR(100);
	DECLARE host_session_user VARCHAR(64);
	DECLARE usuario_session_user VARCHAR(64);
		
	DECLARE trx_mysql_thread_id_aux BIGINT(4);
	DECLARE processlist_id BIGINT(4);
	
	/* sqlstates */
	DECLARE tabla_no_existe CONDITION FOR SQLSTATE '42S02';
	DECLARE sintaxis_acceso_error CONDITION FOR SQLSTATE '42000';
	DECLARE fallo_comunicacion CONDITION FOR SQLSTATE '08S01';
	DECLARE error_general CONDITION FOR SQLSTATE 'HY000';
	
	/* variables */
	DECLARE eof BOOLEAN;
	DECLARE segundos INTEGER;
	DECLARE estado INTEGER;	
	DECLARE msg VARCHAR(255);
		
	
	/* cursores */
	
	
	/* busca logins los cuales el PROCESSLIST.ID asociado no exista */
	DECLARE 
	
		logins_sin_logout
		
	CURSOR FOR
	
		(SELECT 
			l.trx_mysql_thread_id,
			l.id_login,
			l.id_person,
			l.usuario_sistema
		FROM
			logins l
		WHERE
			fecha_hora_logout IS NULL);
			
			
		
	/* flag fetch cursors */
	DECLARE CONTINUE HANDLER 
		FOR 
			NOT FOUND 
		BEGIN
			SET eof = TRUE;
		END;
	/* handler para errores */
	DECLARE EXIT HANDLER 
		FOR 
			sintaxis_acceso_error
		BEGIN 
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de sintaxis o error de acceso';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			fallo_comunicacion
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de comunicacion';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			error_general
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error general';
		END;
		
	
	
		
		
	/* -------------------------- */
	/* inicia variables de sesion */
	/* -------------------------- */
	
	/* usuario de mysql */
	SET usuario_session_user = SUBSTRING_INDEX(SESSION_USER(),'@',1);
	
	/* host */
	SET host_session_user = SUBSTRING_INDEX(SESSION_USER(),'@',-1);
	
	/* id processlist de coneccion */
	SET processlist_id = CONNECTION_ID();
	
	
	
	
	/* ------------------------------ */	
	/* check login del usuario activo */
	/* ------------------------------ */
	
	/* setea a OK */
	SET estado=0;
	SET segundos=0;	
	SET eof=FALSE;
	
	OPEN logins_sin_logout;
			
	bucle_logins_usuarios_sin_logout:
	
	/* check si existe mas de un hilo en esta situacion */
	
	LOOP
	
		FETCH 
			logins_sin_logout 
		INTO 
			trx_mysql_thread_id_aux,
			id_login_aux,
			id_person_aux,
			usuario_sistema_aux;
			
			
		IF eof=TRUE THEN
								
			/* sale del bucle */
			LEAVE bucle_logins_usuarios_sin_logout;
			
		END IF;
		
		/* check usuario login */
		IF	id_person_aux = id_person AND
			usuario_sistema_aux = usuario_sistema THEN
			
			/* usuario logeado */
	
			/* check si esta en el mismo hilo de ejecucion */
			IF processlist_id = trx_mysql_thread_id_aux THEN
				
				/* cierra el login anterior */
				UPDATE
					logins
				SET
					fecha_hora_logout = DATE_ADD(NOW(),INTERVAL segundos SECOND),
					evento = 'desconexion por login de usuario abierto con el mismo hilo'
				WHERE
					id_login = id_login_aux;
								
			END IF;
				
			/* segundos++ */	
			SET segundos=segundos+1;
	
			/* NOTA: se va agregando un segundo por loop por la */ 
			/* clave unica (trx_mysql_thread_id-fecha_hora_logout) */
			/* de manera de asegurarse cerrar todos los logins con */
			/* igual numero de thread_id */
			
		END IF;
	
	END LOOP;
			
	CLOSE logins_sin_logout;
	
	
	
	
	
	
	/* ---------------------------------------------- */
	/* check clave PROCESSLIST.ID - fecha_hora_logout */
	/* ---------------------------------------------- */
	
	/* HIPOTESIS: los ID de proceso no se repiten, en caso de que */
	/* el servidor se reinicie, la fecha_hora_logout del usuario es */
	/* la que valida que no se repita el registro */
	
	/* setea a OK */
	SET estado=0;
	SET segundos=0;	
	SET eof=FALSE;
	
	OPEN logins_sin_logout;
			
	bucle_logins_sin_logout:
	
	/* check si existe mas de un hilo en esta situacion */
	
	LOOP
	
		FETCH 
			logins_sin_logout 
		INTO 
			trx_mysql_thread_id_aux,
			id_login_aux,
			id_person_aux,
			usuario_sistema_aux;
			
		IF eof=TRUE THEN
								
			/* sale del bucle */
			LEAVE bucle_logins_sin_logout;
			
		END IF;
		
		/* aparentemente el login existe o nunca se desconecto */
		IF trx_mysql_thread_id_aux = processlist_id THEN
		
		
			/* cierra el login anterior */
			UPDATE
				logins
			SET
				fecha_hora_logout=DATE_ADD(NOW(),INTERVAL segundos SECOND),
				evento = 'desconexion por thread_id abierto'
			WHERE
				id_login = id_login_aux;
			
				
			/* segundos++ */	
			SET segundos=segundos+1;
	
			/* NOTA: se va agregando un segundo por loop por la */ 
			/* clave unica (trx_mysql_thread_id-fecha_hora_logout) */
			/* de manera de asegurarse cerrar todos los logins con */
			/* igual numero de thread_id */
				
			
		END IF;
		
		
	END LOOP;
			
	CLOSE logins_sin_logout;
	
	
	
	
	
	
	/* ingresa el login de usuario */
	
	/* logins */
	INSERT INTO
		logins
	VALUES
	
		(
		
		/* id_login */
		NULL,
		
		/* trx_mysql_thread_id */
		processlist_id,
		
		/* usuario_db */
		usuario_session_user,
		
		/* host_usuario */
		host_session_user,
		
		/* id_person */
		id_person,
		
		/* usuario_sistema */
		usuario_sistema, 
		
		/* evento */
		'auditoria_conexion',
		
		/* fecha_hora_login */
		NOW(),
		
		/* fecha_hora_logout */
		NULL,
		
		/* fecha_modificacion */
		NULL);
	
			
	/* id login return */
	SET id_login_out = LAST_INSERT_ID();
			
END */$$
DELIMITER ;

/* Procedure structure for procedure `auditar_garbage_collector` */

/*!50003 DROP PROCEDURE IF EXISTS  `auditar_garbage_collector` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `auditar_garbage_collector`(
    			OUT estado INTEGER,
				OUT msg VARCHAR(255))
    COMMENT 'cierra logins sin PROCESSLIST.ID'
BEGIN
	/* sqlstates */
	DECLARE tabla_no_existe CONDITION FOR SQLSTATE '42S02';
	DECLARE sintaxis_acceso_error CONDITION FOR SQLSTATE '42000';
	DECLARE fallo_comunicacion CONDITION FOR SQLSTATE '08S01';
	DECLARE error_general CONDITION FOR SQLSTATE 'HY000';
	
	/* variables */
	DECLARE eof BOOLEAN;
	DECLARE cantidad INT;
	
	
	DECLARE id_login_aux INTEGER;
	DECLARE trx_mysql_thread_id_aux BIGINT(4);
	DECLARE id_aux INTEGER;
	DECLARE cant INTEGER;
	
	DECLARE segundos INTEGER;
	
	
	/* cursores */
	
	/* busca logins los cuales el PROCESSLIST.ID asociado no exista */
	DECLARE 
	
		logins_sin_logout
		
	CURSOR FOR
	
		(SELECT 
			l.id_login,
			l.trx_mysql_thread_id
		FROM
			logins l
		WHERE
			l.fecha_hora_logout IS NULL);
			
		
	/* flag fetch cursors */
	DECLARE CONTINUE HANDLER 
		FOR 
			NOT FOUND 
		BEGIN
			SET eof = TRUE;
		END;
	/* handler para errores */
	DECLARE EXIT HANDLER 
		FOR 
			sintaxis_acceso_error
		BEGIN 
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de sintaxis o error de acceso';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			fallo_comunicacion
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error de comunicacion';
		END;
	DECLARE EXIT HANDLER 
		FOR 
			error_general
		BEGIN 
		
			/* return error */
			SET estado=1;
			/* mensaje */
			SET msg='Error general';
		END;
		
	/* setea a OK */
	SET estado=0;
	SET segundos=0;	
	
	
	OPEN logins_sin_logout;
			
	bucle_logins_sin_logout:
	
	LOOP
	
		FETCH 
			logins_sin_logout 
		INTO 
			id_login_aux,
			trx_mysql_thread_id_aux;
			
		IF eof=TRUE THEN
								
			/* sale del bucle */
			LEAVE bucle_logins_sin_logout;
			
		END IF;
		/* busca en PROCESSLIST el id de hilo del login */
		(SELECT
			COUNT(*) 
		INTO
			cant
		FROM
			INFORMATION_SCHEMA.PROCESSLIST pl
		WHERE
			pl.ID = trx_mysql_thread_id_aux);
			
		/* check si esta existe el hilo */
		IF cant=0 THEN
		
			/* cierra el logins porque el hilo de proceso no existe */
			UPDATE
				logins
			SET
				fecha_hora_logout = DATE_ADD(NOW(),INTERVAL segundos SECOND),
				evento = 'desconexion por garbage collector'
			WHERE
				id_login = id_login_aux;
				
			/* segundos++ */
			SET segundos=segundos+1;
			
		END IF;
		
	END LOOP;
			
	CLOSE logins_sin_logout;
		
	
	
	
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
